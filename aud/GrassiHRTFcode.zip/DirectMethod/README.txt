Subject:
Re: HRTF code
From:
Elena Grassi <egrassi@umd.edu>
Date:
Wed, 10 May 2006 17:17:25 -0400
To:
Lee Miller <leemiller@ucdavis.edu>

Lee, here is one of the latest versions that I used for acquisition in my old direct setup. It has a lot of things that may not concern your setup though. Since my experiment is quite lengthy i have ways to make sure that the user can stop and restart the experiment, alarms to tell the experimenter that the subject moved or stopped, etc. commands for the motor, reordering of elevations, and lots of other things that do not apply to you. Please feel free to ask questions if the useful code is too cluttered by the other stuff.
Please delete all the subjects names that i may have forgot in there before you have anyone else looking at the code! sorry i was supposed to do myself!

I'm also including some of the signals that I used although I do not recall all their properties, so look at the spectrum in the freq domain to see if you like them (83333 is the sampling freq i used, so of course if you use another sampling freq you will have to produce another excitation signal to preserve the properties). The file siggen should contain how to generate most of the signals so you can modify to generate your own.


hope this is not too overwhelming. I'm sure the excitement of having a new hrtf setup will help you cope!

best,
-elena
