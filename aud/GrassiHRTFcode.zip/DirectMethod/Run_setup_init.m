% Run_setup_init: This needs to be run before calling RUN_setup
% Open serial port and set the zero position for the hoop motor


ni_card_no= 3 % 1 (new) or 2 and 3 old or 4 (new)
% Loudspeaker positions (use 6 loudspeakers) %***
% 
% % % speaker_array= ...
% % %    [ 80,  nan, 20, 0, -20, -80;
% % %    85, 55, 5,  -5, -55, -85;
% % %    75, 45, 15, -15, -45, -75;
% % %    70, 50, 10, -10, -50, -70;
% % %    65, 35, 25, -25, -35, -65;
% % %    60, 40, 30, -30, -40, -60];
% % % 

% % %    speaker_array= ...
% % %    [ 60, 40, 20, 0, -40, -60];

speaker_array= ...
   [  65, 35, 20, 0, -35, -65];
%****
% 
% % %  speaker_array= ...
% % %  [   85,        31,       18,          -18,         -31,     -85;
% % %      NaN,       59,       30,             0,        -30,     -59; 
% % %      NaN,       53,       35,           NaN,        NaN,     -53    ];
% % % 
%speaker_array= ... %*** this speaker array seems to be bad in that it
%doesnot blance torque and hoop felt (before i changed position of counter
%weights)
%   [ 60, 40, 10, -10, -40, -60;
%   65, 35, 5, -5, -35, -65;
%   70, 50, 30, -30, -50, -70;
%   75, 45, 15, -15, -45, -75;
%   85, 55, 25,  -25, -55, -85;
%   80,  nan, 20, 0, -20, -80];

save speakers speaker_array

if ~exist('s'),
    s = serial('COM1');
    set(s,'BaudRate',9600,'Parity','none','StopBits', 1,'DataBits', 8);
    fopen(s),
% Do  not run if the motor has already been initialized
    fprintf(s,'%s','Z '); %Resetting motor so current position=0
end
fprintf(s,'%s','MP ') %setting position mode...for updating A,V,P on the fly!
pause(1);

% MOTOR PARAMETERS
vel = 75000; %velocity 
acc = 10; %=40 %acceleration

%set PID filter parameters

fprintf(s,'%s','KI30 ') % Integral gain. Default is 20
fprintf(s,'%s','KL80 ') %Sets a limit on the effects of the KI term. Default:32512
fprintf(s,'%s','KP400 ') %Proportional gain, tends to make the motor stiffer
fprintf(s,'%s','KS15 ') %Set the number of samples used in computing the integral term
fprintf(s,'%s','KD200 ') % Derivative gain.
fprintf(s,'%s','F ') %All the K tuning parameters take effect when F is issued

fprintf(s,'%s',['V',int2str(vel),' ']);
fprintf(s,'%s',['A',int2str(acc),' ']);

% MOTOR  COMMANDS: move hoop to elevation where louspeakers can be changed

newelvn = 90-90; % add -90 if started upright; +90 if in lower position
rev = newelvn/360; 
pos = round(rev*2000*100); %position
%send commands to motor
fprintf(s,'%s',['P',int2str(pos),' ']);
fprintf(s,'%s','G '); %Telling the motor to go
fprintf(s,'%s','MP ');
pause(0.5)
while motor_moving_test(s)==1, pause(0.5), end
disp('motor done')

disp([' Set up loudspeakers in their initial position']);
posstr=''; 
for i=1:6, posstr= strcat(posstr, ['   ', int2str(speaker_array(1,i))]); end

disp([' Position speakers at ' , posstr])

% run C code to use card 1 as master clock and card 2 as slave. Then:
%***RTSIClockConnect
% % NOTE
% % the next 2 lines worked with matlab 6.5 but are giving a warning in
% matlab 7 sp1.
% % bt= sprintf('%s',fread(s,1,'char')); while bt~='R',  bt= sprintf('%s',fread(s,1,'char')); end
% % sprintf('%s',fread(s,3,'char')), bt= sprintf('%s',fread(s,1,'char'))% read flag
% % This is the modification for matlab 7:
% % bt= char(fread(s,1,'char')); while bt~='R',  bt= char(fread(s,1,'char')); end
% % char(fread(s,3,'char')); bt= char(fread(s,1,'char')) % read flag
