% Based on RUN_setup_wo_sensor_April_28_05.m
%********************
%add check for saturation of mic signal
%interrupt if went out of panel *during* the signal
%remove up and down of hoop
% shorten rest time of hoop (perhaps make it a function of elevation: when hoop is coming down tends to vibrate more.)
% check for delay in betweek loudspeakers in same elevation
% check if pulses can be made a little longer and reduce nreps?
%********************************************
% EG. May 17 05. We modify the latest setup program that was ment to
% measure
% static objects (manikin, sphere) and re-introduce the controls that were
% in place earlier for the measurement of HRTFs in humans.
% 1) the control button, 2) the head sensor 3)
% alarms for the experimenter and subject 4) flag to restart the program in the event that some problem were to occur.
% Compared to old HRTFs experiments done back in 2002 - 2003, the new HRTFs
% are taken to slightly different positions because the hoop was
% recalibrated. Also, the new measuring room 3123 is much more noisier and
% has longer RIR.
%% EG March 2005. Modified to eliminate subfolder directory structure.
%
% EG Jan 2004. This program is different than the old RUN_setup_wo_sensor used in HRTF
% in that it plays the pulses one by one and, to save storage, it does not record silent periods.
% This is to move hoop to given location, and produce signal from one 6 loudspeakers and record

% BEFORE running this program you should:
% make sure window is closed, speaker for experimenter is connected, any source of noise (telephone, some lights, fans?) are turned off
% TAKE MICROPHONE CALIBRATION (mikes suspended in middle of hoop without head) for each subject.
% 0) calibrate and initialize hoop upright (+90 deg position).
% 1) create a directory that corresponds to the name dirstr
% 1.1) adjust nreps and nsilence frame_length=  1500%***
% 2) Connect all mics to their corresponding preamp channels (1-2)
% 3) Power motor with e.g. 32 Volts and control card/preamps with +9 and -9
% 4) modify the dirstr and inform variables in this program.
% 5) run Run_setup_init.
% 6) discharge speakers
% 7) connect a speaker to pc if error sound notification is desired
% 8) make sure solar panel starts in error mode: shine light on panel and remove it
%
% If something goes wrong during the experiment and you wish to repeat the experiment starting with the last elevation runned
% you can set the interrupted_flag= 1
%
% AFTER running this program, you should
% 1) Make your subdirectories read only, while allowing to write to the main dirstr directory
% 2) If desired, obtain headphone calibration data
%--------------------------------------------------------------
% Also used to record calibration microphone: connected to ch1 in preamps
% Collected for all 6 speakers at elevation= 0.
%--------------------------------------------------------------
% Both the output signal is sent through NI card 1, and the 64 inputs are acquired trough
% National Instruments card 1 and 2.
%
% The sound production and acquisition are simultaneously triggered by DIO0 falling
% edge trough a direct connection to Trig1 and Trig6.
% Whenever sound is being played through analog output 0, input is read on analog
% input channels 0 and 1.

% note 1: a DC value needs to be added to signals if the control card is powered
% with only positive power supply (this is filtered out by the capacitors,
% but avoids the signal being clipped by the demux max388). To power the card with +9 only
% a jumper switch needs to be set inside the control card.
%
% note 2: DIO0 is used to produce hwd trigger. DIO1-3 is channel select
% Switch signal connected to DIO7 (1= no pressed or open, 0= pressed or closed).
% This signal is used to bypass the sensor if pressed for more than 4 sec.
%

% disp('WARNING   WARNING  WARNING  WARNING   WARNING')
gridstr= 'grid_dp' % matlab file containing elevation coordinate ( -40<elc<180-(-40) ) and azimuth (azc)
% gridstr= 'grid_dpx' % matlab file containing elevation coordinate ( -55<elc<180-(-65) ) and azimuth (azc)
%gridstr= 'grid_dp10' % matlab file containing 10-deg-spaced coordinates ( -50<elc<180-(-65) ) and azimuth (azc), 245 positions
% gridstr= 'grid_dp40' %
% gridstr= 'grid_sphere_mesh_1' %*** matlab file containing elevation coordinates of sphere mesh for reciprocal HRTF
%gridstr= 'grid_dpxx' % matlab file containing elevation coordinate ( -55<elc<180-(-65) ) intermediates elvations were added. and azimuth (azc) -85 to 85 in steps of 5 deg.

% dirstr= 'C:\HRTF_setup_data\dat_miccal_H1_H2\'; % May 26. mic  capibration. 'mics labeled H1 and H2 in chs 1 and 2 respectively of box. blocked ear canal. kemar calibrated with level. rm 3123. upsweep. ']
% dirstr= 'C:\HRTF_setup_data\dat_dmitry_on_recprocity_grid_1\'; % May 26. use with micdirstr= 'C:\HRTF_setup_data\dat_miccal_H1_H2\'; Dmitry blocked ear canal at same 32 positions as the sphere mesh used for reciprocity
% dirstr= 'C:\HRTF_setup_data\dat_tmp\'; % May 26. use with micdirstr= 'C:\HRTF_setup_data\dat_miccal_H1_H2\'; Dmitry blocked ear canal at same 32 positions as the sphere mesh used for reciprocity
% dirstr= 'C:\HRTF_setup_data\dat_Haixia\'; % June 7/05. use with micdirstr= 'C:\HRTF_setup_data\dat_miccal_I1_I2\'; Haixia blocked ear canal on dp grid (at 997 positions).
% dirstr= 'C:\HRTF_setup_data\dat_miccal_I1\'; % % June 8/05. microphone calibration rm 3123.
% dirstr= 'C:\HRTF_setup_data\dat_catherine_1\'; % % June 22-23/05. use with micdirstr= 'C:\HRTF_setup_data\dat_miccal_I1\';'C:\HRTF_setup_data\dat_miccal_I2\'; Catherine Plaisant blocked ear canal on dp grid (at 997 positions). rm 3123. upsweep.
% dirstr= 'C:\HRTF_setup_data\dat_catherine_3\'; % % it seems that on the last round there was a bad signal at some elevations (it looks like it saturated) so some elevations were retaken with a range of [-5,5].
dirstr= 'C:\HRTF_setup_data\dat_temp\'; % % June 9/05. use with micdirstr= 'C:\HRTF_setup_data\dat_miccal_I1_I2\'; Haixia blocked ear canal on dp grid (at 997 positions). rm 3123. upsweep.

% inform= [dirstr, ':greenhead right ear.in box 2, ch 1.upsweep, prbs,noise,impulse, downsweep, long sines. we skept short sines. ']
%***inform= [dirstr, ':mic is labeled Right and has wires bent forward for human HRTFs. mic claibration for greenhead right ear HRTF (left ear is broken) upsweep, prbs,noise,impulse, downsweep, long sines. we skept short sines. ']
% inform= [dirstr, ':mic labeled field 1 etc, to be used for left ear in ch1. mic labeled KR will be used for right ear in box ch2. rm 3123. upsweep, prbs,noise,impulse, downsweep, short sines at high sampling rates. ']
inform= [dirstr, ':mics labeled I1 and I2 in chs 1 and 2 respectively of box. blocked ear canal. rm 3123. upsweep. ']
motor_on_right_of_subject= 0;

%FLAGS
interrupted_flag = 0; %%%****IF THE PROGRAM WAS INTERRUPTED, SET THIS FLAG TO 1 SO THAT IT CAN CONTINUE beginning at the last elevation (all speakers will play).
%%% start from the row of speaker array that was last run and the elevation that was last played in that speaker array.
%%% Once this round of speaker array finishes, the flag is set to 0 so the program can continue normally.
some_speaker_play_flag= 0; % flag to decide if azc is in the current speaker array row.
overwrite_flag=1; %*** overwrite data files in the dirstr directory.
by_pass_light_permission= 1; % by pressing the button for more than 3 sec light control is bypassed.
by_pass_light_flag=0; %flags that user has pressed the reset button for >3sec indicating that he whishes to by pass
by_pass_all_controls_flag= 0; %*** when set to 1, all controls (solar panel and push button) are disregarded.
controls_fine= 1;
error_dont_display_flag=0;

ch_fac= 1.75 % if ch_fac= 1.75, weakest (speaker) channel plays 75% louder
ch_eq= 1./[0.071, 0.145, 0.14, 0.065, 0.065, 0.058];
ch_eq= ch_fac*ch_eq./max(ch_eq); % channel equalization factor: if ch_fac= 1.75, weakest channel plays 75% louder

load  speakers speaker_array % loads values set in run_setup_init. this is to avoid that array becomes modified after initialization (for example by running run_mic_cal) and gets the wrong values.
if motor_on_right_of_subject== 0,  speaker_array= - speaker_array; end

% delay from sound production to sound arrival at ears is approximately 3 ms
fsi_desired = 83333; % sampling frequency for AI
% fsi_desired = 166666.7; %*** sampling frequency for AI
fso_desired = fsi_desired; % sampling frequency for AO


% diplay_range= 160*2:800*2; %*** one pulse diplay window
diplay_range= 160:800; %*** one pulse diplay window
nreps = 18;
% nsilence=  round(40e-3*fsi_desired/100)*100; % play long silence, need about 40 msec: 0.04/npts*39000= 10.4
nsilence=  round(150e-3*fsi_desired/100)*100; %*** play long silence, need about 150 msec
% nsilence=  round(300e-3*fsi_desired/100)*100; %*** play long silence, need about 150 msec
% % frame_length=  npts+250; % data acquired for each pulse: % npts+ safety for delay; ndelay is about round(3e-3*39000)=117;
frame_length=  1500 ; % npts+ margin; % modified  june 14 04. data acquired for each pulse: % npts+ safety for delay; ndelay is about round(3e-3*39000)=117;
% % % frame_length=  4000; % npts+ margin; % modified  june 14 04. data acquired for each pulse: % npts+ safety for delay; ndelay is about round(3e-3*39000)=117;
% frame_length=  1500*2 ; %*** npts+ margin; % modified  june 14 04. data acquired for each pulse: % npts+ safety for delay; ndelay is about round(3e-3*39000)=117;
nn_pts= frame_length*nreps; % frame_length*nreps
% since we only add channels that we use, they now become 1,2,...
% To avoid aliasing, intermediate channels must be added and sampled.
% From 2005, preamps are wired so that odd channels 1,3,... in NI card
% become connected to ground. So if we need 2 channels, we add channels
% [0:3] and then only save [1,3]
save_chs_1= [1,3] % 1=first channel ADDED: channels as added in analog object~=box channels: 2,4,6,8 sphere mics 10,12,14,16 vicinity
save_chs_2= [];

data_type= 'native'; % or default is 'double'
dc_value= 0; % see note 1

% DIGITAL I/O --------------------------------------------------------------------
dio = digitalio('nidaq', ni_card_no);%  nidaq is an adaptor, 1 is the device identifier.

% define  output digital lines
% connect DIO_0 to Analog in triggers.  DIO_1-3 index loudspeaker to be played in multiplexer.
addline(dio, 0:3, 'out'); %  0:3- hardware lines added to device object. dio.Line(1): to give trigger; dio.Line(2-4): address loudspeaker
putvalue(dio.Line(1), 1); % initial conditions%    writes data to the hardware lines specified by obj.Line(index)
% define  input digital lines
addline(dio, 5:7, 'in'); % 5: output of flip-flop, 6: negated solar panel signal(0= light on, 1= light off), 7: reset switch connected to reset of flip flop.

% Analog Output channel --------------------------------------------------------------------
ao= analogoutput('nidaq', ni_card_no);% creates analog output object ao for nidaq (adaptor) and for hardware device with identifier 1
addchannel(ao,[0]);%  adds hardware channel ([0]) to device object (ao).
%initialize output channel
set(ao,'SampleRate',fso_desired);
set(ao,'TriggerType','HwDigital');
set(ao, 'RepeatOutput',0) ;  % no repeat: default

fso= get(ao,'SampleRate')  % get actual sample rate

% Analog Input object -------------------------------------------------------------------
%initialize the channel
if ~isempty(save_chs_1)
   ai1 = analoginput('nidaq',ni_card_no);
   set(ai1,'InputType', 'SingleEnded');
   addchannel(ai1,[0,1,2,3]);  %**** we only add the channels we need to sample
   set(ai1,'SampleRate',fsi_desired) %  max sample rate= 1.25e6/channels added
   set(ai1,'SamplesPerTrigger', frame_length)
   fsi1= get(ai1,'SampleRate')  % get actual sample rate
   disp('warning **********************')
   % %    set(ai1.Channel([2,4,6,8]),'InputRange',[-2.5 2.5]);% default is [-5,5]
   set(ai1.Channel,'InputRange',[-2.5 2.5]);%*** default is [-5,5]
   %            set(ai1.Channel,'InputRange',[-0.5 0.5]);%*** default is [-5,5]
   %    set(ai1.Channel,'InputRange',[-1 1])%*** default is [-5,5]
   InputRange1= get(ai1.Channel,'InputRange');
   disp('Input Channel card 1:'), get(ai1.Channel(1),'InputRange')
   set(ai1,'TriggerType','HwDigital');  % falling edge
   Channel_info_1= ai1.Channel;
end

if ~isempty(save_chs_2)
   ai2 = analoginput('nidaq',2);
   set(ai2,'InputType', 'SingleEnded');
   addchannel(ai2,0:31);  %see NOTE5: addchannel(ai2,[0:3, 5:31]);  % [1:4, 6:32]
   set(ai2,'SampleRate',fsi_desired) %  max sample rate= 1.25e6/32
   set(ai2,'SamplesPerTrigger', frame_length)
   fsi2= get(ai2,'SampleRate')  %get actual sample rate
   set(ai2.Channel,'InputRange',[-2.5 2.5]);%*** default is [-5,5]
   %     set(ai2.Channel,'InputRange',[-1 1]);% default is [-5,5]
   InputRange2= get(ai2.Channel,'InputRange')
   disp('Input Channel card 2:'), get(ai2.Channel(2),'InputRange')
   set(ai2,'TriggerType','HwDigital');
   Channel_info_2=ai2.Channel;
end

% ALARM SIGNALS
t1 = 1/fso*[0:5000].'; n_repeat= round(1/t1(end)); % figure out how many times to repeat to play 1 sec
errorSound = sin(1000*2*pi*t1); % sound to notify subject: 1kHz
t1 = 1/8000*[0:4000-1].'; %0.5 sec
errorSound_user= [ [sin(1000*2*pi*t1); zeros(4000,1)] , zeros(8000,1)]; %1 sec, only left speaker plays: sound to notify user (experimenter)

% TEST SIGNALS
silence = zeros(nsilence,1);
% f_v= round(logspace(log10(500), log10(8000), 10)./100)*100; % sins frequencies
f_v= [];%***1200,2400,4800,9600];
% f_v= [1000, 1500, 2000, 2500, 3000, 4000, 5000];
sin_amp= 2; % sins amplitude
nf= length(f_v);
% long_sin_npts= 1000;
long_sin_npts=0; %*** if no long sine signals will be used

% % % % load upsweep_signal_39000 u %****
% % signal_str= strvcat( 'upsweep_signal_150pts_at_83333')
% % % load upsweep_signal_39000 u %****
% % % signal_str= strvcat( 'upsweep_signal_150pts_at_83333',...
% % %    'prbs_signal_130pts_at_83333',...
% % %    'noise_signal_150pts_at_83333',...
% % %    'impulse_signal_150pts_at_83333',...
% % %    'downsweep_signal_150pts_at_83333');
signal_str= strvcat( 'upsweep_signal_150pts_at_83333')
%***
% % % signal_str= strvcat( 'upsweep_signal_350pts_at_166667', ...
% % %                 'prbs_signal_256pts_at_166667',...
% % %                 'noise_signal_350pts_at_166667',...
% % %                 'impulse_signal_350pts_at_166667',...
% % %                 'downsweep_signal_350pts_at_166667');
nsig= size(signal_str,1); % no. of non-sinusoidal signals
TestSound= cell(nsig,1); % save test signals
for isig=1:nsig,
   load(deblank(signal_str(isig,:)),'u');
   TestSound{isig,1}= [u;silence]+ dc_value;  % play long silence but can discard some when recording.
end

% Load  grid and sort elevations needed (nelevations total)
eval(['load ', gridstr]) % load elc azc

% OR define it
%***(make sure you use positions contained in pseaker_array)
% % elc=[]; azc=[];  elcv= [-30:15:210].';   azcv= [80,60,40,30, 20,0,-20,-30, -40,-60,-80].';
% azc= 0*ones(size(elc));
%-----------------------
% % elc=[]; azc=[]; elcv= [40].';
% % azcv=   [  60, 40, 0, -20, -40, -60].';
% % for i=1:length(elcv), azc= [azc; azcv]; elc= [elc; elcv(i)*ones(length(azcv),1)]; end
%-----------------------
% % elc=[]; azc=[]; elcv= [0, 90,180].';  azcv=   [  60, 40, 0, -20, -40, -60].';
% % for i=1:length(elcv), azc= [azc; azcv]; elc= [elc; elcv(i)*ones(length(azcv),1)]; end
%-----------------------
% % elc=[]; azc=[]; elcv= [0, 90, 180].';  azcv=   [ 85,      31,    18,     -18,     -31    -85].';
% % for i=1:length(elcv), azc= [azc; azcv]; elc= [elc; elcv(i)*ones(length(azcv),1)]; end

%-----------------------
% elc=[]; azc=[]; elcv= [0, 90,180].';  azcv=     [ 60, 40, 20, 0, -40, -60].';
% for i=1:length(elcv), azc= [azc; azcv]; elc= [elc; elcv(i)*ones(length(azcv),1)]; end



% Additional constraints: -------------------------
%ind= find(elc>=-40); elc= elc(ind); azc= azc(ind);
% ind= find(elc>=-50 & elc<=230); elc= elc(ind); azc= azc(ind); used in % ekemar _HS
% ind= find(elc>=55 & elc<=65); elc= elc(ind); azc= azc(ind); %used in %catherine
%ind= find((azc==0)|(azc==20)|(azc==40)|(azc==60)|(azc==80)|(azc==-20)|(azc==-40)|(azc==-60)|(azc==-80));
%azc= azc(ind); elc= elc(ind);
% end Additional constraints ----------------------

% If the program was interrupted the last time it ran:
if (interrupted_flag)
   disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ');
   disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ');
   disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ');
   disp('WARNING: RUNNING IN INTERRUPTED MODE. PRESS ENTER TO CONTINUE.......');
   disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ');
   disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ');
   disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ');
   pause;
   eval(['load ',dirstr,'last_done elvnV nhoopelvn hoopelvn i_el n speaker_array']);

   n_interrupt = n; % speaker array
   i_interrupt =i_el;
else
   n_interrupt =1;
end

% Loudspeaker positions (use 6 loudspeakers)
nspeaker_array= size(speaker_array,1); % how many times the speaker array needs to be set on the hoop in a different configuration.

for n= n_interrupt : nspeaker_array
   % Only excecute if any azimuth equals one of the current speaker position
   for i=1:6, if any(azc==speaker_array(n,i)) , some_speaker_play_flag=1; end, end
   if some_speaker_play_flag==1 % any azimuth in the current line of speaker array is scheduled to play
      % User needs to arrange the position of the louspeakers:
      % generate string of speaker positions (azimuth)
      posstr='';
      for i=1:6, posstr= strcat(posstr, ['   ', int2str(speaker_array(n,i))]); end

      disp([' Position speakers at ' , posstr])
      disp(' ')
      disp('press any key to move hoop to elevation = 90 so you can check lateral lasers')
      disp('.......................')
      pause

      %------ move motor to to elevation = 90
      newelvn = 90-90; % -90 if started upright; +90 if in lower position
      rev = newelvn/360;
      pos = round(rev*2000*100); %position
      %send commands to motor
      fprintf(s,'%s',['P',int2str(pos),' ']);
      fprintf(s,'%s','G '); %Telling the motor to go
      fprintf(s,'%s','MP ');	%in case the motor was moving when we updated the trajectory
      %It NEEDS to have this (or any other command????%***see manual p.74) command after G to work
      pause(0.5);
      %Wait til motor finishes moving
      while motor_moving_test(s)=='1', pause(0.5), end
      disp('motor done')
      %--end ---- move motor to to elevation = 90

      if ~by_pass_all_controls_flag
         disp('press any key to move hoop to front (-35) and check that knees are ok')
         disp('.......................')
         pause

         %------ move motor to front (-35 deg)
         if motor_on_right_of_subject,
            newelvn = -35-90; % -90 if started upright; +90 if in lower position
         else
            newelvn = (180-(-35))-90; % -90 if started upright; +90 if in lower position
         end
         rev = newelvn/360;
         pos = round(rev*2000*100); %position
         %send commands to motor
         fprintf(s,'%s',['P',int2str(pos),' ']);
         fprintf(s,'%s','G '); %Telling the motor to go
         fprintf(s,'%s','MP ');	%in case the motor was moving when we updated the trajectory
         %It NEEDS to have this (or any other command????%***see manual p.74) command after G to work
         pause(0.5);
         %Wait til motor finishes moving
         while motor_moving_test(s)=='1', pause(0.5), end
         disp('motor done')
         %--end ---- move motor to front (-35) elevation
      end
      disp('press any key to begin')
      disp('.......................')
      pause

      if ~by_pass_all_controls_flag
         while (getvalue(dio.Line(5))==0) % make sure that position sensor starts in error status
            disp([ 'make sure positioning sensor is in error mode (point laser to sensor and move it away)  '])
            disp([ 'and press any key to continue  '])
            pause
         end
         disp('.......... waiting for subject .............')
         % check if subject is ready (head pointing to sensor=1)

         %if the laser is shining on the solar panel, then line 6 is 0. The flip-flop on line 6
         % triggers on edge: when light turns off it becomes 1, when push button is pressed it becomes 0.
         good_to_go_flag=0;
         tic
         while  ~good_to_go_flag% if flip-flop triggered or solar panel is off
            pause(0.2) % wait
            if (getvalue(dio.Line(5)) | getvalue(dio.Line(6)))==0 % flip-flop reset by button AND light on panel
               good_to_go_flag=1;
            elseif (toc>3)% button pressed for more than 4 sec to indicate intention to by-pass
               if by_pass_light_permission, good_to_go_flag=1; by_pass_light_flag=1; end
            elseif getvalue(dio.Line(7))==1, tic % if button released, restart count
            end
         end
      end %--{~by_pass_all_controls_flag}
      %======================= find elevations corresponding to the speaker
      % ====================== that we're going to run this time
      if ~interrupted_flag %If it wasn't interrupted then we need to generate status variables (elevations to traverse in this round).

         hoopelvn= [];
         elvnV = cell(1,6);

         for i=1:6, % loudspeakers
            ind= find(azc==speaker_array(n,i));
            hoopelvn= [hoopelvn; elc(ind)]; elvnV{1,i}= elc(ind);
            if isempty(elvnV{1,i}), elvnV{1,i}= inf; end
         end
         %Sort by ascending elevation:
         hoopelvn = sort(hoopelvn);
         hoopelvn= unique(hoopelvn); % remove repeated elevations
         %***
         %hoopelvn= hoopelvn(length(hoopelvn):-1:1); % uncomment to sort by descending elevation
         nhoopelvn= length(hoopelvn);

         % to fix case when last two elevations are one degree appart
         if any( abs(diff(hoopelvn))==1),
            for ii=1:nhoopelvn-2,
               if abs(hoopelvn(ii)-hoopelvn(ii+1))==1
                  tmp= hoopelvn(ii+2); hoopelvn(ii+2)= hoopelvn(ii+1); hoopelvn(ii+1)= tmp;
               end
            end
            if abs( hoopelvn(nhoopelvn)-  hoopelvn(nhoopelvn-1))==1
               tmp= hoopelvn(nhoopelvn-2); hoopelvn(nhoopelvn-2)= hoopelvn(nhoopelvn-1); hoopelvn(nhoopelvn-1)= tmp;
            end

         end

         if any( abs(diff(hoopelvn))==1),
            error('consecutive elevations only 1 degree appart'),
         end

         %*** check that there are none   [hoopelvn,[0;abs(diff(hoopelvn))]],% keyboard

         i_interrupt = 1;

      end %-{if ~interrupted_flag}
      for i_el= i_interrupt:nhoopelvn

         % ====================== MOVE MOTOR TO THAT ELEVATION ================

         if motor_on_right_of_subject,
            newelvn = hoopelvn(i_el)-90; % -90 if started upright; +90 if in lower position
         else
            newelvn = (180-hoopelvn(i_el))-90; % -90 if started upright; +90 if in lower position
         end
         rev = newelvn/360;
         pos = round(rev*2000*100); %position

         %send commands to motor
         fprintf(s,'%s',['P',int2str(pos),' ']);
         fprintf(s,'%s','G '); %Telling the motor to go
         fprintf(s,'%s','MP ');	%in case the motor was moving when we updated the trajectory
         %It NEEDS to have this (or any other command????%***see manual p.74) command after G to work
         pause(0.5);

         %Wait til motor finishes moving
         while motor_moving_test(s)=='1', pause(0.5), end
         disp('motor done')

         pause(6) % wait for vibration to die out
         %==================================================================
         %
         %  OUTPUT ONE STREAM OF DATA FOR EACH LOUDSPEAKER AND ACQUIRE DATA
         %
         %==================================================================


         speaker=1;
         while (speaker<=6 ) % for each speaker, we check if the speaker needs to play
            controls_fine=1; % to allow speaker increment if speaker is not scheduled to play
            if any(elvnV{1,speaker}==hoopelvn(i_el)) % if speaker needs to play sound
               %%%%% if speaker is scheduled to play and subject not ready play error sound
               if ~by_pass_all_controls_flag
                  if (getvalue(dio.Line(5))|getvalue(dio.Line(6))) % if flip-flop triggered (light went off) or if solar panel light is off
                     %%%%%%%%%% Play error sound %#***may be should only play error if not in by-pass mode
                     set(ao, 'RepeatOutput',n_repeat) ;  %%***** output n+1 times, can use n=inf too
                     putdata(ao, errorSound); % queue data for output
                     start(ao); %send speaker output to let subject know that he/she went out of position
                     putvalue(dio.Line(1), 0); % falling edge gives trigger
                     wait(ao,4) % wait til stop or timeout in 4 sec
                     putvalue(dio.Line(1), 1); % restore trigger line to 1
                     set(ao, 'RepeatOutput',0) ;  % restore to no repeat
                     for ii=1: 2, sound(0.5*errorSound_user,8000), end % tell experimenter that subject went out of focus
                     pause(2)
                     %%%%%end-{play error sound} %%%%%%%%%%%
                     %%%%%%% wait for subject or by-pass %%%%%%%%%%%
                     good_to_go_flag=0;
                     tic
                     while  ~good_to_go_flag% if flip-flop triggered or solar panel is off
                        pause(0.2) % wait
                        if (getvalue(dio.Line(5)) | getvalue(dio.Line(6)))==0 % flip-flop reset by button AND light on panel
                           good_to_go_flag=1;
                        elseif (toc>3)% button pressed for more than 34 sec to indicate intention to by-pass
                           if by_pass_light_permission, good_to_go_flag=1; by_pass_light_flag=1; end
                        elseif getvalue(dio.Line(7))==1, tic % if button released, restart count
                        end
                     end %%%%%%% {wait for subject or by-pass} %%%%%%%%%%%

                  end
               end %--{if ~by_pass_all_controls_flag}
               %%%%%%%%%%%%%%%%%%%%% Data acquisition  %%%%%%%%%%%%%%%%%%%%%%%%%
               Data1= cell(1,nsig+ 2*nf);  Data2= cell(1, nsig+2*nf); % (signal_type,  Data1: card1)
               % %                     % sweep Data1{1,1} Data2{1,1}. sin data: {1,2:end}
               for ii=1: nf+1 , Data1{1,ii}= int16(zeros(nn_pts,length(save_chs_1))); Data2{1,ii}= int16(zeros(nn_pts,length(save_chs_2))); end% sines
               putvalue(dio.Line(2:4), speaker-1) % index the multiplexer. no need to convert to digital and write it backwards

               %----- play a zero sound to give time for possible speaker discharge (some clicks were heard when switching speaker)
               putdata(ao, silence );
               start([ao]);
               putvalue(dio.Line(1), 0); % falling edge gives trigger
               wait([ao],2)
               putvalue(dio.Line(1), 1); % restore trigger line to 1
               %---end -- play a zero sound

               %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
               diplay_range= 160:800; % one pulse diplay window
               for isig=1:nsig  % no. of non-sinusoidal signals
                  %--------------------------------------------------------------------
                  %   SEND OUT ONE TEST SIGNAL
                  %--------------------------------------------------------------------
                  dio_val = (getvalue(dio.Line(5)) | getvalue(dio.Line(6))); %we also check for light in case button was pushed by mistake
                  if by_pass_all_controls_flag | by_pass_light_flag | (dio_val==0)

                     for iii=1: nreps
                        % queue data for output
                        % we play long silence to work as a timer
                        putdata(ao, ch_eq(speaker)* TestSound{isig,1} ); % equalize magnitude

                        %send speaker output and record data from microphone
                        if ~isempty(save_chs_1)&~isempty(save_chs_2), start([ao, ai1, ai2]);
                        elseif ~isempty(save_chs_1), start([ao, ai1]);
                        elseif ~isempty(save_chs_2), start([ao, ai2]);
                        end

                        putvalue(dio.Line(1), 0); % falling edge gives trigger

                        % aquiring the data
                        off0= (iii-1)*frame_length;
                        if ~isempty(save_chs_1)&~isempty(save_chs_2),  wait([ai1,ai2,ao],2) % wait til stop or timeout in 1 sec
                        elseif ~isempty(save_chs_1),  wait([ai1, ao],2) %used to be waittilstop (now obsolete)
                        elseif ~isempty(save_chs_2),  wait([ai2, ao],2)
                        end

                        % record selected channels:
                        if ~isempty(save_chs_1)
                           tmp = getdata(ai1,frame_length, data_type); Data1{1,isig}(off0+ [1:frame_length],:)= tmp(:,save_chs_1);
                        end
                        if ~isempty(save_chs_2)
                           tmp = getdata(ai2,frame_length, data_type); Data2{1,isig}(off0+ [1:frame_length],:)= tmp(:,save_chs_2);
                        end
                        % restore trigger line to 1
                        putvalue(dio.Line(1), 1);
                     end


                     % -------------------------- Display --------------------------------------------

                     figure(1)
                     if data_type(1)=='n', % native
                        if ~isempty(save_chs_1)
                           NativeScaling = get(ai1.Channel(save_chs_1(1)),'NativeScaling'); % Use only 1 channel if all are set to the same range %***
                           NativeOffset = get(ai1.Channel(save_chs_1(1)),'NativeOffset'); % Use only 1 channel if all are set to the same range %***
                           DData1= double(Data1{1,isig})*NativeScaling + NativeOffset;
                           subplot(2,2,1), plot(DData1),ylabel('1:32'), title(['  el= ', int2str( hoopelvn(i_el) ), ' az= ' ,  int2str(speaker_array(n,speaker))]), aaa= axis; axis([aaa(1:2), InputRange1{1}(1),InputRange1{1}(2)])
                           subplot(2,2,3), plot(DData1(diplay_range,:)), title(signal_str(isig,1:9)), ylabel('1:32') , aaa= axis; %axis([1,320, aaa(3:4)])
                        else
                           subplot(2,2,1), ylabel('1:32'), title(['  el= ', int2str( hoopelvn(i_el) ), ' az= ' ,  int2str(speaker_array(n,speaker))]),
                           subplot(2,2,3), ylabel('1:32'),
                        end
                        if ~isempty(save_chs_2)
                           NativeScaling = get(ai2.Channel(save_chs_2(1)),'NativeScaling'); % Use only 1 channel if all are set to the same range %***
                           NativeOffset = get(ai2.Channel(save_chs_2(1)),'NativeOffset'); % Use only 1 channel if all are set to the same range %***
                           DData2= double(Data2{1,isig})*NativeScaling + NativeOffset;
                           subplot(2,2,2), plot(DData2),ylabel('33:64'), aaa= axis; axis([aaa(1:2),InputRange2{1}(1),InputRange2{1}(2)])
                           subplot(2,2,4), plot(DData2(diplay_range,:)),ylabel('33:64'), aaa= axis; axis([1,320, aaa(3:4)])
                        else
                           subplot(2,2,2), ylabel('33:64')
                           subplot(2,2,4), ylabel('33:64')
                        end
                     else
                        if ~isempty(save_chs_1)
                           subplot(2,2,1), plot(Data1{1,isig}),ylabel('1:32'), title(['  el= ', int2str( hoopelvn(i_el) ), ' az= ' ,  int2str(speaker_array(n,speaker))]), aaa= axis; axis([aaa(1:2),InputRange1{1}(1),InputRange1{1}(2)])
                           subplot(2,2,3), plot(Data1{1,isig}(diplay_range,:)), title(signal_str(isig,1:9)),ylabel('1:32') , aaa= axis; axis([1,320, aaa(3:4)])
                        else
                           subplot(2,2,1), ylabel('1:32'),  title(['  el= ', int2str( hoopelvn(i_el) ), ' az= ' ,  int2str(speaker_array(n,speaker))])
                           subplot(2,2,3), ylabel('1:32'),
                        end
                        if ~isempty(save_chs_2)
                           subplot(2,2,2), plot(Data2{1,isig}),ylabel('33:64'), aaa= axis; axis([aaa(1:2), InputRange2{1}(1),InputRange2{1}(2)])
                           subplot(2,2,4), plot(Data2{1,isig}(diplay_range,:)),ylabel('33:64'), aaa= axis; axis([1,320, aaa(3:4)])
                        else
                           subplot(2,2,2), ylabel('33:64')
                           subplot(2,2,4), ylabel('33:64')
                        end
                     end
                     drawnow
                     % end  --------------------- Display --------------------------------------------
                  end %---{if by_pass_all_controls_flag | by_pass_light_flag | (dio_val==0)}
               end %----- for isig=1:nsig --------------------------

               %the following lines should stay here if short sins are commented out
               npts= [];
               t= [];
               % % % %
               % % % %
               % % % %                                    %--------------------------------------------------------------------
               % % % %                                    %   COMPOSE AND SEND OUT SHORT SINUSOID TEST SIGNAL
               % % % %                                    %--------------------------------------------------------------------
               % % % %                                    diplay_range= 160:800*2; %*** one pulse diplay window
               % % % %                                    npts= 150;
               % % % %                                    t= 1/fso*[0:npts-1].';
               % % % %
               % % % %                                    for ii=1: nf % freq of sinusoids
               % % % %                                        u= sin_amp*sin(2*pi*f_v(ii)*t).* hanning(npts);
               % % % %                                        SinSound = [u;silence]+dc_value;
               % % % %                                        for iii=1: nreps
               % % % %
               % % % %                                            % queue data for output: we play long silence, but we only record a short one
               % % % %                                            putdata(ao, ch_eq(speaker)* SinSound ); % ch_eq(speaker): equalize magnitude
               % % % %
               % % % %                                            %send speaker output and record data from microphone
               % % % %                                            if ~isempty(save_chs_1)&~isempty(save_chs_2), start([ao, ai1, ai2]);
               % % % %                                            elseif ~isempty(save_chs_1), start([ao, ai1]);
               % % % %                                            elseif ~isempty(save_chs_2), start([ao, ai2]);
               % % % %                                            end
               % % % %
               % % % %                                            putvalue(dio.Line(1), 0); % falling edge gives trigger
               % % % %
               % % % %                                            % aquiring the data
               % % % %                                            off0= (iii-1)*frame_length;
               % % % %                                            if ~isempty(save_chs_1)&~isempty(save_chs_2),  wait([ai1,ai2,ao],2) % wait til stop or timeout in 1 sec
               % % % %                                            elseif ~isempty(save_chs_1),  wait([ai1, ao],1)
               % % % %                                            elseif ~isempty(save_chs_2),  wait([ai2, ao],1)
               % % % %                                            end
               % % % %                                            % record selected channels:
               % % % %                                            if ~isempty(save_chs_1)
               % % % %                                                tmp = getdata(ai1,frame_length, data_type); Data1{1,nsig+ii}(off0+ [1:frame_length],:)= tmp(:,save_chs_1);
               % % % %                                            end
               % % % %                                            if ~isempty(save_chs_2)
               % % % %                                                tmp = getdata(ai2,frame_length, data_type); Data2{1,nsig+ii}(off0+ [1:frame_length],:)= tmp(:,save_chs_2);
               % % % %                                            end
               % % % %
               % % % %                                            % restore trigger line to 1
               % % % %                                            putvalue(dio.Line(1), 1);
               % % % %                                        end
               % % % %
               % % % %                                        % --------------------- Display --------------------------------------------
               % % % %                                        figure(1)
               % % % %                                        if data_type(1)=='n', % native
               % % % %                                            if ~isempty(save_chs_1)
               % % % %                                                NativeScaling = get(ai1.Channel(save_chs_1(1)),'NativeScaling'); % Use only 1 channel if all are set to the same range %***
               % % % %                                                NativeOffset = get(ai1.Channel(save_chs_1(1)),'NativeOffset'); % Use only 1 channel if all are set to the same range %***
               % % % %                                                DData1= double(Data1{1,nsig+ii})*NativeScaling + NativeOffset;
               % % % %                                                subplot(2,2,1), plot(DData1),ylabel('1:32'), title(['  el= ', int2str( hoopelvn(i_el) ), ' az= ' ,  int2str(speaker_array(n,speaker))]), aaa= axis; axis([aaa(1:2),  -2,2])
               % % % %                                                subplot(2,2,3), plot(DData1(diplay_range,:)),ylabel('1:32') , aaa= axis; %axis([1,320, aaa(3:4)])
               % % % %                                            else
               % % % %                                                subplot(2,2,1), ylabel('1:32'), title(['  el= ', int2str( hoopelvn(i_el) ), ' az= ' ,  int2str(speaker_array(n,speaker))])
               % % % %                                                subplot(2,2,3), ylabel('1:32'),
               % % % %                                            end
               % % % %                                            if ~isempty(save_chs_2)
               % % % %                                                NativeScaling = get(ai2.Channel(save_chs_2(1)),'NativeScaling'); % Use only 1 channel if all are set to the same range %***
               % % % %                                                NativeOffset = get(ai2.Channel(save_chs_2(1)),'NativeOffset'); % Use only 1 channel if all are set to the same range %***
               % % % %                                                DData2= double(Data2{1,nsig+ii})*NativeScaling + NativeOffset;
               % % % %                                                subplot(2,2,2), plot(DData2),ylabel('33:64'), title(['freq= ', int2str( f_v(ii) )]), aaa= axis; axis([aaa(1:2),  -2,2])
               % % % %                                                subplot(2,2,4), plot(DData2(diplay_range,:)),ylabel('33:64'), aaa= axis; axis([1,320, aaa(3:4)])
               % % % %                                            else
               % % % %                                                subplot(2,2,2), ylabel('33:64'),title(['freq= ', int2str( f_v(ii) )])
               % % % %                                                subplot(2,2,4), ylabel('33:64')
               % % % %                                            end
               % % % %                                        else
               % % % %                                            if ~isempty(save_chs_1)
               % % % %                                                subplot(2,2,1), plot(Data1{1,nsig+ii}),ylabel('1:32'), title(['  el= ', int2str( hoopelvn(i_el) ), ' az= ' ,  int2str(speaker_array(n,speaker))]), aaa= axis; axis([aaa(1:2),  -2,2])
               % % % %                                                subplot(2,2,3), plot(Data1{1,nsig+ii}(diplay_range,:)),ylabel('1:32') , aaa= axis; axis([1,320, aaa(3:4)])
               % % % %                                            else
               % % % %                                                subplot(2,2,1), ylabel('1:32'), title(['  el= ', int2str( hoopelvn(i_el) ), ' az= ' ,  int2str(speaker_array(n,speaker))])
               % % % %                                                subplot(2,2,3), ylabel('1:32'),
               % % % %                                            end
               % % % %                                            if ~isempty(save_chs_2)
               % % % %                                                subplot(2,2,2), plot(Data2{1,nsig+ii}),ylabel('33:64'), aaa= axis; axis([aaa(1:2),  -2,2]) ,title(['freq= ', int2str( f_v(ii) )])
               % % % %                                                subplot(2,2,4), plot(Data2{1,nsig+ii}(diplay_range,:)),ylabel('33:64'), aaa= axis; axis([1,320, aaa(3:4)])
               % % % %                                            else
               % % % %                                                subplot(2,2,2), ylabel('33:64'),title(['freq= ', int2str( f_v(ii) )])
               % % % %                                                subplot(2,2,4), ylabel('33:64')
               % % % %                                            end
               % % % %                                        end
               % % % %                                        drawnow
               % % % %                                        % end  --------------------- Display --------------------------------------------
               % % % %
               % % % %                                    end %----- for ii=1: nf % freq of sinusoids
               % % % %
               % % % %                                    %--------------------------------------------------------------------
               % % % %                                    %   COMPOSE AND SEND OUT LONG SINUSOID TEST SIGNAL
               % % % %                                    %--------------------------------------------------------------------
               % % % %                                    % here sins will have echoes so there will be bias, but I hope that making a long window
               % % % %                                    % there will be less effect of variance due to window
               % % % %                                    % notches?
               % % % %                                    t_long= 1/fso*[0:long_sin_npts-1].';
               % % % %                                    diplay_range= 160:2500; % one pulse diplay window
               % % % %
               % % % %                                    for ii=1: nf % freq of sinusoids
               % % % %                                        u= sin_amp*sin(2*pi*f_v(ii)*t_long).* hanning(long_sin_npts);
               % % % %                                        SinSound = [u;silence]+dc_value;
               % % % %                                        for iii=1: nreps
               % % % %
               % % % %                                            % queue data for output: we play long silence, but we only record a short one
               % % % %                                            putdata(ao, ch_eq(speaker)* SinSound ); % ch_eq(speaker): equalize magnitude
               % % % %
               % % % %                                            %send speaker output and record data from microphone
               % % % %                                            if ~isempty(save_chs_1)&~isempty(save_chs_2), start([ao, ai1, ai2]);
               % % % %                                            elseif ~isempty(save_chs_1), start([ao, ai1]);
               % % % %                                            elseif ~isempty(save_chs_2), start([ao, ai2]);
               % % % %                                            end
               % % % %
               % % % %                                            putvalue(dio.Line(1), 0); % falling edge gives trigger
               % % % %
               % % % %                                            % aquiring the data
               % % % %                                            off0= (iii-1)*frame_length;
               % % % %                                            if ~isempty(save_chs_1)&~isempty(save_chs_2),  wait([ai1,ai2,ao],2) % wait til stop or timeout in 1 sec
               % % % %                                            elseif ~isempty(save_chs_1),  wait([ai1, ao],1)
               % % % %                                            elseif ~isempty(save_chs_2),  wait([ai2, ao],1)
               % % % %                                            end
               % % % %                                            % record selected channels:
               % % % %                                            if ~isempty(save_chs_1)
               % % % %                                                tmp = getdata(ai1,frame_length, data_type); Data1{1,nsig+nf+ii}(off0+ [1:frame_length],:)= tmp(:,save_chs_1);
               % % % %                                            end
               % % % %                                            if ~isempty(save_chs_2)
               % % % %                                                tmp = getdata(ai2,frame_length, data_type); Data2{1,nsig+nf+ii}(off0+ [1:frame_length],:)= tmp(:,save_chs_2);
               % % % %                                            end
               % % % %
               % % % %                                            % restore trigger line to 1
               % % % %                                            putvalue(dio.Line(1), 1);
               % % % %                                        end
               % % % %
               % % % %                                        % --------------------- Display --------------------------------------------
               % % % %                                        figure(1)
               % % % %                                        if data_type(1)=='n', % native
               % % % %                                            if ~isempty(save_chs_1)
               % % % %                                                NativeScaling = get(ai1.Channel(save_chs_1(1)),'NativeScaling'); % Use only 1 channel if all are set to the same range %***
               % % % %                                                NativeOffset = get(ai1.Channel(save_chs_1(1)),'NativeOffset'); % Use only 1 channel if all are set to the same range %***
               % % % %                                                DData1= double(Data1{1,nsig+nf+ii})*NativeScaling + NativeOffset;
               % % % %                                                subplot(2,2,1), plot(DData1),ylabel('1:32'), title(['  el= ', int2str( hoopelvn(i_el) ), ' az= ' ,  int2str(speaker_array(n,speaker))]), aaa= axis; axis([aaa(1:2),  -2,2])
               % % % %                                                subplot(2,2,3), plot(DData1(diplay_range,:)),ylabel('1:32') , aaa= axis; %axis([1,320, aaa(3:4)])
               % % % %                                            else
               % % % %                                                subplot(2,2,1), ylabel('1:32'), title(['  el= ', int2str( hoopelvn(i_el) ), ' az= ' ,  int2str(speaker_array(n,speaker))])
               % % % %                                                subplot(2,2,3), ylabel('1:32'),
               % % % %                                            end
               % % % %                                            if ~isempty(save_chs_2)
               % % % %                                                NativeScaling = get(ai2.Channel(save_chs_2(1)),'NativeScaling'); % Use only 1 channel if all are set to the same range %***
               % % % %                                                NativeOffset = get(ai2.Channel(save_chs_2(1)),'NativeOffset'); % Use only 1 channel if all are set to the same range %***
               % % % %                                                DData2= double(Data2{1,nsig+nf+ii})*NativeScaling + NativeOffset;
               % % % %                                                subplot(2,2,2), plot(DData2),ylabel('33:64'), title(['freq= ', int2str( f_v(ii) )]), aaa= axis; axis([aaa(1:2),  -2,2])
               % % % %                                                subplot(2,2,4), plot(DData2(diplay_range,:)),ylabel('33:64'), aaa= axis; axis([1,320, aaa(3:4)])
               % % % %                                            else
               % % % %                                                subplot(2,2,2), ylabel('33:64'),title(['freq= ', int2str( f_v(ii) )])
               % % % %                                                subplot(2,2,4), ylabel('33:64')
               % % % %                                            end
               % % % %                                        else
               % % % %                                            if ~isempty(save_chs_1)
               % % % %                                                subplot(2,2,1), plot(Data1{1,nsig+nf+ii}),ylabel('1:32'), title(['  el= ', int2str( hoopelvn(i_el) ), ' az= ' ,  int2str(speaker_array(n,speaker))]), aaa= axis; axis([aaa(1:2),  -2,2])
               % % % %                                                subplot(2,2,3), plot(Data1{1,nsig+nf+ii}(diplay_range,:)),ylabel('1:32') , aaa= axis; axis([1,320, aaa(3:4)])
               % % % %                                            else
               % % % %                                                subplot(2,2,1), ylabel('1:32'), title(['  el= ', int2str( hoopelvn(i_el) ), ' az= ' ,  int2str(speaker_array(n,speaker))])
               % % % %                                                subplot(2,2,3), ylabel('1:32'),
               % % % %                                            end
               % % % %                                            if ~isempty(save_chs_2)
               % % % %                                                subplot(2,2,2), plot(Data2{1,nsig+nf+ii}),ylabel('33:64'), aaa= axis; axis([aaa(1:2),  -2,2]) ,title(['freq= ', int2str( f_v(ii) )])
               % % % %                                                subplot(2,2,4), plot(Data2{1,nsig+nf+ii}(diplay_range,:)),ylabel('33:64'), aaa= axis; axis([1,320, aaa(3:4)])
               % % % %                                            else
               % % % %                                                subplot(2,2,2), ylabel('33:64'),title(['freq= ', int2str( f_v(ii) )])
               % % % %                                                subplot(2,2,4), ylabel('33:64')
               % % % %                                            end
               % % % %                                        end
               % % % %                                        drawnow
               % % % %                                        % end  --------------------- Display --------------------------------------------
               % % % %
               % % % %                                    end %----- for ii=1: nf % freq of sinusoids
               % % % %
               %--------------------------------------------------------------------
               %%%%%%%%%%%%%%%%% SAVE DATA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
               % Save Data into corresponding file: subdirectory= azimuth, filename= azimuth_elevation

               elstr= ang2str(hoopelvn(i_el));
               azstr= ang2str(speaker_array(n,speaker));
               disp(['speaker=  ', int2str(speaker),  '  el= ', int2str( hoopelvn(i_el) ), ' az= ' ,  azstr ])

               disp('data being saved.....')
               filestr= [dirstr,'A',azstr,'E',elstr];  %filestr= [dirstr,azstr,'\',azstr,elstr,int2str(j)];

               ok_flag=0; dd= dir([filestr,'.mat']); eval('err_fil=dd.name;', 'ok_flag=1;');
               if ok_flag|overwrite_flag
                  save(filestr, 'Data1', 'Data2','-v6'); disp('done')
               else
                  error(['file ', err_fil, ' already exixts. Please clear directories and type ''return''!!!'])
                  keyboard
               end

               %%%%%%%%%%%%%%%%%%%%%%%%%%%%% check if subject maintained position, else play alarm and repeat speaker %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
               % if flip-flop triggered it means that light on solar panel went off during signal play, in which case speaker must be repeated (no speaker increment).
               if ~by_pass_all_controls_flag
                  dio_val = (getvalue(dio.Line(5)) | getvalue(dio.Line(6))); %# we also check for light in case button was pushed by mistake(is this needed?)
                  if(dio_val==1)&~by_pass_light_flag % if flip-flop triggered or solar panel is off and user has not requested a by-pass
                     controls_fine=0;
                  else % if nothing went wrong with laser OR we are in by-pass-light mode, move on to next speaker and leave by-pass mode
                     % if we by-passed for some reason other than occlusion (like for a test) as soon as normal conditions are met (light presence and ff was reset) we should leave light by-pass mode
                     if by_pass_light_flag==1,
                        display('***************************** Leaving by-pass mode *********************'),
                        by_pass_light_flag= 0;
                     end
                     controls_fine=1;
                     eval(['save ',dirstr,'last_done elvnV nhoopelvn hoopelvn i_el n speaker_array -v6'])
                  end
               else
                  controls_fine=1;
                  eval(['save ',dirstr,'last_done elvnV nhoopelvn hoopelvn i_el n speaker_array -v6'])
               end %--{if ~by_pass_all_controls_flag}
            end %%-{if any(elvnV{1,speaker}==hoopelvn(i_el)) % if speaker needs to play sound at this elevation

            if controls_fine  %if ff not triggered or we're in bypass mode, allow to pass to next speaker
               speaker = speaker+1; % move on to the next speaker
            end
         end %---------- while (speaker<=6 )
      end %-------{for i_el= i_interrupt:nhoopelvn}
      soundsc(errorSound_user,8000) % tell user that run has finished
      some_speaker_play_flag= 0; % reset flag
      %-------bring hoop to a comfortable position to change speakers
      if motor_on_right_of_subject,
         newelvn = -35-90; % -90 if started upright; +90 if in lower position
      else
         newelvn = (180-215)-90; % -90 if started upright; +90 if in lower position
      end

      rev = newelvn/360;
      pos = round(rev*2000*100); %position

      %send commands to motor
      fprintf(s,'%s',['P',int2str(pos),' ']);
      fprintf(s,'%s','G '); %Telling the motor to go
      fprintf(s,'%s','MP ');

      % here we dont need tocheck that trajectory is finished!
      %--- end ----bring hoop to a comfortable position to change speakers

   end %{if any loudspeaker in this arrangement is scheduled to play}
   interrupted_flag =0;
end % end { n= n_interrupt:nspeaker_array }
%==================================================================
if ~isempty(save_chs_1),
   if data_type(1)=='n', % native
      NativeScaling1= ai1.Channel.NativeScaling;
      NativeOffset1=  ai1.Channel.NativeOffset;
   else
      NativeScaling1={};  NativeOffset1=   {};
   end

   InputRange1= get(ai1.Channel,'InputRange');
   Channel_info_1= ai1.Channel;
   disp('Input Channel card 1:'), Channel_info_1.InputRange
else
   fsi1=[]; InputRange1= {};  NativeScaling1={};  NativeOffset1=   {}; Channel_info_1= {};
end
if ~isempty(save_chs_2),
   if data_type(1)=='n', % native
      NativeScaling2= ai2.Channel.NativeScaling;
      NativeOffset2=  ai2.Channel.NativeOffset;
   else
      NativeScaling2={};  NativeOffset2=   {};
   end
   InputRange2= get(ai2.Channel,'InputRange');
   Channel_info_2= ai2.Channel;
   disp('Input Channel card 2:'),   , Channel_info_2.InputRange
else
   fsi2=[]; InputRange2= {};  NativeScaling2={};  NativeOffset2=   {}; Channel_info_2= {};
end

% to recover double data from native type use: datadouble = double(nativedata)*daqhwinfo_ai1.NativeDataType + daqhwinfo_ai1.NativeOffset;
% clean up
% fclose(s), delete(s),clear s,
% delete(ai1); delete(ao); delete(dio); RTSIClockDisconnect
% delete(ai2);
% clear;

%%%%%%%%%%%Clean up the last_done file so that it doesn't mess up data if someone forgets to reset the interrupt flag
hoopelvn =0;
nhoopelvn =0;
elvnV=0;
i_el=0; n=0;
speaker_array = 0;
eval(['save ',dirstr,'last_done elvnV nhoopelvn hoopelvn i_el n speaker_array -v6'])
%%%%%%%%%%%% end Clean up the last_done %%%%%%%%%%%%%%%%%

disp(['Done with data collection! ... saving parameters in ', dirstr])
eval(['save ',dirstr,'param data_type elc azc fsi1 fsi2 fso npts  nreps nsilence frame_length nn_pts dc_value save_chs_1 save_chs_2 signal_str TestSound  f_v ch_eq ch_fac speaker_array inform overwrite_flag NativeScaling1 NativeOffset1 InputRange1 NativeScaling2 NativeOffset2 InputRange2 long_sin_npts ni_card_no -v6'])


% NOTES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The sound production and acquisition are simultaneously triggered by DIO0 falling
% edge trough a direct connection to Trig1 and Trig6.
% Whenever sound is being played through analog output 0, input is read on analog
% input channels 0 and 1.
%
% April 18. Switch signal connected to DIO7 (1= no pressed or open, 0= pressed or closed).
% This signal is used to bypass the sensor if pressed for more than 4 sec.

% note 1: a DC value needs to be added to signals if the control card is powered
% with only positive power supply (this is filtered out by the capacitors,
% but avoids the signal being clipped by the demux max388). To power the card with +9 only
% a jumper switch needs to be set inside the control card.
%
% note 2: DIO0 is used to produce hwd trigger. DIO1-3 is channel select
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NOTE1:        % stop([ao, ai]); %*** stop should only be issued when the devices are running
% on inf samples. Otherwise, ai stops acquiring after SamplesPerTrigger
% samples are collected. ao stops when the queued data finishes
% NOTE2:
% n=inf; set(ao, 'RepeatOutput',n) inf should only be used for long outputs
% NOTE3: apparently the samples per trigger have to be bigger than ~10000
% NOTE4: The amplifiers in the control box are inverter amplifiers.
%*** possible additions: % At the beginning we should take a sample of the noise inside the chamber
% NOTE5:  Some mics are absent, could skip those channels if want to have higher sampling rate or more time to save to disk. addchannel(ai1,[0:10, 12:22, 24:27, 29:31]);
% NOTE6:
% % the next 2 lines worked with matlab 6.5 but are giving a warning in
% matlab 7 sp1.
% % bt= sprintf('%s',fread(s,1,'char')); while bt~='R',  bt= sprintf('%s',fread(s,1,'char')); end
% % sprintf('%s',fread(s,3,'char')), bt= sprintf('%s',fread(s,1,'char'))% read flag
% % This is the modification for matlab 7:
% % bt= char(fread(s,1,'char')); while bt~='R',  bt= char(fread(s,1,'char')); end
% % char(fread(s,3,'char')); bt= char(fread(s,1,'char')) % read flag

%
% Switch  connected to DIO7 (1= no pressed or open, 0= pressed or closed).
%

%*** do not repeat if playing one by one set(ao, 'RepeatOutput',nreps) ;  %%***** output n+1 times, can use n=inf too
% for i=1:16, plot([Data1{1,i}(4500:5500,[12,24,29]),Data2{1,i}(4500:5500,[5])] ), pause, end


%mic1: 5 in Data2, Mic2: 12, Mic3: 29, Mic4: 24