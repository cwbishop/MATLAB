function siggen(fso, fs_v, nsin, filestr);
% function siggen(fso, fs_v, nsin, filestr);
% Generates a series of sine pulses at frequencies fs_v(i).
% fs= sample rate
% fs_v: vector of frequencies
% example fso= 83333; nsin= 250; siggen(fso, [700, 1500, 2500, 3500, 4000, 4500], nsin, 'sin_signal_')

nfs= length(fs_v);
windowstr= 'hanning';
t= 1/fso*[0:nsin-1].';
for i=1:nfs
    u= sin(2*pi*fs_v(i)*t).* hanning(nsin);
    figure(1), U= abs(fft(u,512)); 
    subplot(2,1,1),plot(t,u), subplot(2,1,2), plot(fso/512*[0:256-1], U(1:256))
    pause
    eval(['save ', filestr, int2str(i), ' t u fso windowstr']) % sin_signal_1, sin_signal_2,...
end

break
% % % to generate sweep of about 4 msec
% % fs1= 39000; % desired sample rate, actual may be slightly different. max sample rate= 1.25e6/32 
% % nsweep= 150;
% % % generate sweep for sphere HRTF %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % rise= 0.02;
% % f0= 400; f1= 12e3;
% % t= 1/fs1*[0:nsweep-1].';
% % 
% % u=chirp(t,f0,nsweep/fs1,f1,'linear',90); %90 deg phase to be a sin (starts at zero)
% % u= u.*trapez(length(u),rise); % apply trapezoidal window to ensure that starts and ends at 0.
% % % save upsweep_signal_39000 u t


break
% to generate sweep of about 3.6 msec
fs1= 83333; % desired sample rate, actual may be slightly different. max sample rate= 1.25e6/No of channels 
nsweep= 300;
% generate sweep for sphere HRTF %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rise= 0.02;
f0= 500; f1= 10e3;
t= 1/fs1*[0:nsweep-1].';

u=chirp(t,f0,nsweep/fs1,f1,'linear',90); %90 deg phase to be a sin (starts at zero)
u= u.*trapez(length(u),rise); % apply trapezoidal window to ensure that starts and ends at 0.
% save upsweep_signal_83333 u t

break
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% to generate upsweep of about 1.8 msec
fs1= 83333; % desired sample rate, actual may be slightly different. max sample rate= 1.25e6/No of channels 
nsweep= 150;
% generate sweep for sphere HRTF %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rise= 0.02;
f0= 600; f1= 15e3;
t= 1/fs1*[0:nsweep-1].';

u=chirp(t,f0,nsweep/fs1,f1,'linear',90); %90 deg phase to be a sin (starts at zero)
u= u.*trapez(length(u),rise); % apply trapezoidal window to ensure that starts and ends at 0.
% save upsweep_signal_150pts_at_83333 u t

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% generate short (approx 150 pts) ML-PRBS (MLS) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dt= 12e-6; clock_per= 2; nprbs= 63*clock_per; nnoise=150; rise= 0.02;

nnn= nprbs/clock_per;
if(nnn==63)
   u0=[1;1;1;1;1;1]; % initial condition: different than 0!!! 2^n , n is the number of ones in the intial conditions
elseif(nnn==127)
   u0=[1;1;1;1;1;1;1]; % initial condition: different than 0!!! 2^n , n is the number of ones in the intial conditions
elseif(nnn==255)
   u0=[1;1;1;1;1;1;1;1]; % initial condition: different than 0!!! 2^n , n is the number of ones in the intial conditions
end

[u,t]= ml_prbs(u0,dt,clock_per,nprbs); 
ind= find(u==0); u(ind)= -1*ones(1,length(ind));
figure(2),stairs(t,u)
subplot(2,1,1)
stairs(t,u), axis([0,1.6e-3,-1.2,1.2]), xlabel('time'), ylabel('amplitude')
subplot(2,1,2)
xx= abs(fft(u)).^2; xx= xx(1:63); ff= 1/dt/(length(u))*[0:62];
plot(ff,xx), xlabel('freqency'), ylabel('PSD')

% smooth out corners
% u= u.*trapez(length(u),rise); 
u= [0;0;u;0;0]; t= [t, t(end)+dt, t(end)+2*dt, t(end)+3*dt, t(end)+4*dt]; % make sure that starts and ends at zero before filtering
[b,a]= butter( 4, 0.5);  % 0.5= 1/4 sampling freq: 2pt averaging
u= filtfilt(b,a,u);
subplot(2,1,1), hold on, plot(t,u,'r'), hold off
subplot(2,1,2), hold on, xx= abs(fft(u)).^2; xx= xx(1:66); ff= 1/dt/(length(u))*[0:65];
plot(ff,xx,'r'), hold off

% save prbs_signal_130pts_at_83333 u t


%%%%%%%%%%%%%%% generate band noise between 600 Hz and 15 kHz %%%%%%%%%%%%%%%%%%%
nnoise= 150; rise= 0.02; winflag=1; dt= 12e-6;
f0= 600; f1= 15e3;

t= dt*[0:nnoise-1]; 
rand('state',0)
xx=(rand(nnoise,1)-0.5)*2; % to make the range  -1 to +1
half_fs= 83333/2;
[B_filt,A_filt]= butter(4,[ f0/half_fs, f1/half_fs ]); % f1= 600; f0=15e3
u= 1.8* filter(B_filt,A_filt,xx); % this one introduces phase shift but in this case we do not care about it
if winflag, u= u.*trapez(length(u),rise); end
%***pow = cov(u); u = u/sqrt(pow);
figure(3), subplot(2,1,1),plot(t,u), xlabel('time'), ylabel('amplitude')
xx= abs(fft(u)).^2; xx= xx(1:76); ff= 1/dt/nnoise*[0:75];
subplot(2,1,2),
plot(ff,xx), xlabel('freqency'), ylabel('PSD')

% save noise_signal_150pts_at_83333 u t

%%%%%%%%%%%%%%%%%% generate pulse %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nimpulse= 150;
f0= 600; f1= 15e3; half_fs= 83333/2; dt= 12e-6;
t= dt*[0:nimpulse-1];
[B_filt,A_filt]= butter(4,[ f0/half_fs, f1/half_fs ]); 
sys1= tf(B_filt, A_filt, dt);
u= 8*impulse(sys1,t);
figure(4), subplot(2,1,1),plot(t,u), xlabel('time'), ylabel('amplitude')
xx= abs(fft(u)).^2; xx= xx(1:76); ff= 1/dt/nnoise*[0:75];
subplot(2,1,2),
plot(ff,xx), xlabel('freqency'), ylabel('PSD')
% save impulse_signal_150pts_at_83333 u t

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% to generate downsweep of about 1.8 msec
fs1= 83333; % desired sample rate, actual may be slightly different. max sample rate= 1.25e6/No of channels 
nsweep= 150;
rise= 0.02;
f0= 600; f1= 15e3;
t= 1/fs1*[0:nsweep-1].';

u=chirp(t,f1,nsweep/fs1,f0,'linear',90); %90 deg phase to be a sin (starts at zero)
u= u.*trapez(length(u),rise); % apply trapezoidal window to ensure that starts and ends at 0.
% save downsweep_signal_150pts_at_83333 u t
