% Elena Grassi Feb 21 06
% Run reciprocal HRTFs measurement w/o sensors. 32 channels in each NI
% card, 4 cards (128 ch total).
% signals (TestSound: can select a list containing any of the following upsweep, prbs, noise, impulse, long cosines)
% for a distance of about 60cm, signal should be
% designed of about 2.5 ms (acount for about 1.2 ms IR and 3.5 ms time for echo to
% come back but relax a bit because low freq that happen first should not bounce back that much).
% if running the subject in more than one position, e.g., 2 positions, we can pretend that the loudspeakers are repositioned to a different azimuth (eg, 1 and 2 in first row of speaker array, for left and right ear, and thern 3 and 4 in the second row of speaker array for left and ear.
% enter azcv=   [1, 2, 3, 4].';
%
%*********************
% EG March 23/06: modified to sample from alternating mics to allow for a higher
% sampling rate.
% EG March 28/06: modified to sample from alternative ears
% (left_right_alternate_flag)
% EG March 30/06: modified to store NativeScaling and NAtiveOffset per
% channel and per loudspeaker, even in the case of highsampling.

% This program plays the pulses one by one and, to save storage, it does not record silent periods.
% This program produces signal from one of 6 loudspeakers and records
% from 128 channels simultaneously.
% BEFORE running this program you should:
% 1) create a directory that corresponds to the name dirstr
% 2) Connect all mics to their corresponding preamp channels (1-32 in 4
% boxes) taking note of what region corresponds to what box (use var inform).
% 4) modify the dirstr and inform variables in this program.
% 5) run Run_Rec_setup_init.
% 6) Have subject sign the informed consent.
% 7) position speaker 1 into left ear and speaker 2 into right ear.

% AFTER running this program, you should
% 1) Make your subdirectories read only, while allowing to write to the main dirstr directory
% 2) run Run_mic_cal, to obtain microphone
%    calibration signals (mikes suspended in middle of hoop without head) for each subject.
%
% HWD NOTES: One of the boxes (e.g. 4) is connected to the external control
% and output power amp card. This connects DIO0 with AItrigger and AO
% trigger in the corresponding card. The sound production and acquisition are simultaneously triggered by DIO0 falling
% edge trough a direct connection to Trig1 and Trig6. This trigger signal must be
% connected also to the AI trigger in all the other boxes (pin 38).
% Whenever sound is being played through analog output 0, input is read on analog
% input channels 0:2:63.

% note 1: a DC value needs to be added to signals if the control card is powered
% with only positive power supply (this is filtered out by the capacitors,
% but avoids the signal being clipped by the demux max388). To power the card with +9 only
% a jumper switch needs to be set inside the control card.
%
% note 2: DIO0 is used to produce hwd trigger. DIO1-3 is channel select
% coordinate of the mics in spherical coordinates elc azc (x front z right
% y up)
dirstr= 'c:\Rec_setup_data\dat'; azcv=   [1,2, 3,4 ].'; %%%left and right speaker  April 12/06 calibration with better sweep signal and preemphasis preemph_upsweep_800to18000_98pts_at_39063 (old one had bad response over 10 khz). Speakers left and right. and longer rest period

%HS, HS_alt,LS
% which correspond to top, front, back, left and right.

highsamp_flag=1;
speaker_alternate_flag= 0;

inrange= [-0.5 0.5]

% acquired from mic at center of hoop.postcalibration
% inform= [dirstr, ':human subjects, both ears, upsweep. ']
inform= [dirstr, ':March 20/06 calibration with better sweep signal preemph_upsweep_800to18000_98pts_at_39063 (old one had bad response over 10 khz). Speakers left and right. and longer rest period . ']


ch_fac= 1.75% if ch_fac= 1.75, weakest (speaker) channel plays 75% louder than original signal
% ch_eq= 1./[0.2,0.6,0.6,0.6,0.6,1];
ch_eq= 1./[0.3,1,1,0.3,1,1];
% ch_eq= 1./[1,1,1,1,1,1];
ch_eq= ch_fac*ch_eq./max(ch_eq); % channel equalization factor: if ch_fac= 1.75, weakest channel plays 75% louder

overwrite_flag=1; %*** overwrite data files in the dirstr directory.

% % % load  speakers speaker_array % loads values set in run_setup_init. this is to avoid that array becomes modified after initialization (for example by running run_mic_cal) and gets the wrong values.
% speaker_array= [ 1, NaN, 2 , NaN, NaN, NaN]; % sets of "azimuth"
speaker_array= [ 1, NaN, NaN , 2, NaN, NaN;
    3, NaN, NaN , 4, NaN, NaN ]; % sets of "azimuth"
% delay from sound production to sound arrival at ears is approximately 3 ms
nreps = 25; %
% % % nsilence= npts*11; % play long silence, need about 40 msec: 0.04/npts*39000= 10.4
time_silence= 300e-3 % sec. play long silence, need about 300-400 msec in a room with echoes

if highsamp_flag==1,
    ch_array=  [0:2:31; 32:2:63] ;  % add 16 channels first then the other 16
    fsi_desired = 2*39062.5; % sampling frequency for AI
    frame_length=  2048 %*** ; % npts+ margin; % data acquired for each pulse: % npts+ safety for delay; ndelay is about round(3e-3*39000)=117;
%     signal_str= strvcat( 'preemph_upsweep_1000to15000_150pts_at_78125'); u_fact= 1.4;
    signal_str= strvcat( 'preemph_upsweep_1000to15000_142pts_at_78125'); u_fact= 1.4;
    display_range= 60*2:500; % one pulse diplay window

else
    ch_array=  [0:2:63] ;  % add all 32 channels
    fsi_desired = 39062.5; % sampling frequency for AI
    frame_length=  1024 ; % npts+ margin; % data acquired for each pulse: % npts+ safety for delay; ndelay is about round(3e-3*39000)=117;
%     signal_str= strvcat( 'preemph_upsweep_1000to15000_75pts_at_39063'); u_fact= 1.4;
    signal_str= strvcat( 'preemph_upsweep_1000to15000_72pts_at_39063'); u_fact= 1.4;
    display_range= 60:250; % one pulse diplay window
end
fso_desired = fsi_desired; % sampling frequency for AO
nsilence= round(time_silence*fsi_desired);

save_chs_1= [1:32]; % of the ADDED channels
save_chs_2= [1:32];
save_chs_3= [1:32];
save_chs_4= [1:32];

data_type= 'native'; % or default is 'double'
dc_value= 0; % see note 1

%FLAGS
speaker_play_flag= 0; % flag to decide if azc is in the current speaker array row.

% DIGITAL I/O --------------------------------------------------------------------
dio = digitalio('nidaq', 4);%  ('nidaq', 4): nidaq is an adaptor, 1 is the device identifier.

% define  output digital lines
% connect DIO_0 to Analog in triggers.  DIO_1-3 index loudspeaker to be played in multiplexer.
addline(dio, 0:3, 'out'); %  0:3- numeric id's given to hardware lines added to device object.
putvalue(dio.Line(1), 1); % initial conditions%    writes data to the hardware lines specified by obj.Line(index)

% Analog Output channel --------------------------------------------------------------------
ao= analogoutput('nidaq', 4);% creates analog output object ao for nidaq (adaptor) and for hardware device with identifier 1
addchannel(ao,[0]);%  adds hardware channel ([0]) to device object (ao).
%initialize output channel
set(ao,'SampleRate',fso_desired);
set(ao,'TriggerType','HwDigital');
fso= get(ao,'SampleRate')  % get actual sample rate

% Analog Input object -------------------------------------------------------------------
fsi1=[];   fsi2=[];   fsi3=[];   fsi4=[];
%initialize the channel
if ~isempty(save_chs_1)
    ai1 = analoginput('nidaq',1);
    set(ai1,'InputType','SingleEnded');
    addchannel(ai1,ch_array(1,:));  % we only add the channels we need
    set(ai1,'SampleRate',fsi_desired) %  max sample rate= 1.25e6/32
    set(ai1,'SamplesPerTrigger', frame_length)
    fsi1= get(ai1,'SampleRate')  % get actual sample rate
    set(ai1.Channel,'InputRange',inrange);% default is [-5,5]
    disp('Input Channel card 1:'), get(ai1.Channel(1),'InputRange')
    set(ai1,'TriggerType','HwDigital');  % falling edge
end

if ~isempty(save_chs_2)
    ai2 = analoginput('nidaq',2);
    set(ai2,'InputType', 'SingleEnded');
    addchannel(ai2,ch_array(1,:));  % we only add the channels we need
    set(ai2,'SampleRate',fsi_desired) %  max sample rate= 1.25e6/32
    set(ai2,'SamplesPerTrigger', frame_length)
    fsi2= get(ai2,'SampleRate')  % get actual sample rate
    set(ai2.Channel,'InputRange',inrange);% default is [-5,5]
    disp('Input Channel card 2:'), get(ai2.Channel(1),'InputRange')
    set(ai2,'TriggerType','HwDigital');  % falling edge
end
if ~isempty(save_chs_3)
    ai3 = analoginput('nidaq',3);
    set(ai3,'InputType', 'SingleEnded');
    addchannel(ai3,ch_array(1,:));  % we only add the channels we need
    set(ai3,'SampleRate',fsi_desired) %  max sample rate= 1.25e6/32
    set(ai3,'SamplesPerTrigger', frame_length)
    fsi3= get(ai3,'SampleRate')  % get actual sample rate
    set(ai3.Channel,'InputRange',inrange);% default is [-5,5]
    disp('Input Channel card 3:'), get(ai3.Channel(1),'InputRange')
    set(ai3,'TriggerType','HwDigital');  % falling edge
end

if ~isempty(save_chs_4)
    ai4 = analoginput('nidaq',4);
    set(ai4,'InputType', 'SingleEnded');
    addchannel(ai4,ch_array(1,:));  % we only add the channels we need
    set(ai4,'SampleRate',fsi_desired) %  max sample rate= 1.25e6/32
    set(ai4,'SamplesPerTrigger', frame_length)
    fsi4= get(ai4,'SampleRate')  %get actual sample rate
    set(ai4.Channel,'InputRange',inrange);% default is [-5,5]
    disp('Input Channel card 4:'), get(ai4.Channel(1),'InputRange')
    set(ai4,'TriggerType','HwDigital');
end

box_label_str= strvcat( 'front', 'back', 'left', 'right' );
% TEST SIGNALS
silence = zeros(nsilence,1);

% % % signal_str= strvcat( 'upsweep_signal_150pts_at_83333', ...
% % %                 'prbs_signal_130pts_at_83333');

nsig= size(signal_str,1); % no. of non-sinusoidal signals
TestSound= cell(nsig,1); % save test signals
for isig=1:nsig,
    load(deblank(signal_str(isig,:)),'u');  u= u*u_fact; % load u, the signal to be played
    TestSound{isig,1}= [u;silence]+ dc_value;  % play long silence but can discard some when recording.
end

%-----------------------
elc=[]; azc=[]; elcv= [0].'; % here elevation represents the rotation of the person wrt the frontal position

for i=1:length(elcv), azc= [azc; azcv]; elc= [elc; elcv(i)*ones(length(azcv),1)]; end

% Loudspeaker positions (use up to 6 **** or 8 *** loudspeakers)
nspeaker_array= size(speaker_array,1);
nch_array= size(ch_array,1);
InputRange1= cell(1,nsig); InputRange2= cell(1,nsig); InputRange3= cell(1,nsig); InputRange4= cell(1,nsig);
NativeScaling1=cell(1,nsig); NativeScaling2=cell(1,nsig); NativeScaling3=cell(1,nsig); NativeScaling4=cell(1,nsig);
NativeOffset1=cell(1,nsig);  NativeOffset2=cell(1,nsig);  NativeOffset3=cell(1,nsig);  NativeOffset4=cell(1,nsig);

npos= length(elc);

for n= 1:nspeaker_array
    % Only excecute if any azimuth equals one of the current speaker position
    for i=1:6, if any(azc==speaker_array(n,i)) , speaker_play_flag=1; end, end
    if speaker_play_flag==1 % any azimuth in the current line of speaker array is scheduled to play
        % User needs to arrange the position of the louspeakers:
        % generate string of speaker positions (azimuth)
        posstr='';
        for i=1:6, posstr= strcat(posstr, ['   ', int2str(speaker_array(n,i))]); end

        disp([' Position speakers at ' , posstr])
        disp('press any key to begin')
        disp('.......................')
        pause
        pause(5)

        %======================= find elevations corresponding to the speaker
        % ====================== that we're going to run this time
        hoopelvn= [];
        elvnV = cell(1,6);

        for i=1:6, % loudspeakers
            ind= find(azc==speaker_array(n,i));
            hoopelvn= [hoopelvn; elc(ind)]; elvnV{1,i}= elc(ind);
            if isempty(elvnV{1,i}), elvnV{1,i}= inf; end
        end
        %Sort by ascending elevation:
        hoopelvn = sort(hoopelvn);
        hoopelvn= unique(hoopelvn); % remove repeated elevations
        %***
        hoopelvn= hoopelvn(length(hoopelvn):-1:1); % uncomment to sort by descending elevation
        nhoopelvn= length(hoopelvn);

        for i= 1:nhoopelvn

            %==================================================================
            %
            %  OUTPUT ONE STREAM OF DATA FOR EACH LOUDSPEAKER AND ACQUIRE DATA
            %
            %==================================================================

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Make a list of speakers that need to play:
            speaker_play_list= [];
            for speaker=1:6
                if any(elvnV{1,speaker}==hoopelvn(i)) % if speaker needs to play sound
                    speaker_play_list= [speaker_play_list, speaker];
                end
            end
            if speaker_alternate_flag==0,
                speaker_play_list= speaker_play_list.'; % column form, otherwise all speakers in a row are played alternating
            end
            nspeakers= length(speaker_play_list); %either interleaved or individually playing
            


            for speaker_run=1: size(speaker_play_list,1) % no of rows determines the no. of speaker runs (groups of interleaved speakers)

                Data1= cell(1,nsig);  Data2= cell(1,nsig); Data3= cell(1,nsig); Data4= cell(1,nsig); % (signal_type,  Data1: card1)
                InputRan1= cell(1,nsig);InputRan2= cell(1,nsig);InputRan3= cell(1,nsig);InputRan4= cell(1,nsig);
                NativeSca1= cell(1,nsig); NativeSca2= cell(1,nsig); NativeSca3= cell(1,nsig); NativeSca4= cell(1,nsig); 
                NativeOff1= cell(1,nsig); NativeOff2= cell(1,nsig); NativeOff3= cell(1,nsig); NativeOff4= cell(1,nsig);
  
                nspeaker_play= size(speaker_play_list,2); % no of columns determines the no. of speakers that play interleaved
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                for isig=1:nsig  % no. of signals
                    Data1{1,isig}= zeros(nreps*frame_length,32,nspeaker_play);
                    Data2{1,isig}= zeros(nreps*frame_length,32,nspeaker_play);
                    Data3{1,isig}= zeros(nreps*frame_length,32,nspeaker_play);
                    Data4{1,isig}= zeros(nreps*frame_length,32,nspeaker_play);
                    InputRan1{1,isig}= zeros(32,nspeaker_play,2);  InputRan2{1,isig}= zeros(32,nspeaker_play,2);
                    InputRan3{1,isig}= zeros(32,nspeaker_play,2);  InputRan4{1,isig}= zeros(32,nspeaker_play,2);
                    NativeSca1{1,isig}= zeros(32,nspeaker_play); NativeOff1{1,isig}= zeros(32,nspeaker_play);
                    NativeSca2{1,isig}= zeros(32,nspeaker_play); NativeOff2{1,isig}= zeros(32,nspeaker_play);
                    NativeSca3{1,isig}= zeros(32,nspeaker_play); NativeOff3{1,isig}= zeros(32,nspeaker_play);
                    NativeSca4{1,isig}= zeros(32,nspeaker_play); NativeOff4{1,isig}= zeros(32,nspeaker_play);

                    % initialize: Get the cards programmed
                    ich= 1;
                    if ~isempty(save_chs_1)
                        delete(ai1)
                        ai1 = analoginput('nidaq',1);
                        set(ai1,'InputType','SingleEnded');
                        addchannel(ai1,ch_array(ich,:));  % we only add the channels we need
                        set(ai1,'SampleRate',fsi1) %  max sample rate= 1.25e6/32
                        set(ai1,'SamplesPerTrigger', frame_length)
                        set(ai1.Channel,'InputRange',inrange);% default is [-5,5]
                        set(ai1,'TriggerType','HwDigital');  % falling edge
                    end

                    if ~isempty(save_chs_2)
                        delete(ai2)
                        ai2 = analoginput('nidaq',2);
                        set(ai2,'InputType','SingleEnded');
                        addchannel(ai2,ch_array(ich,:));  % we only add the channels we need
                        set(ai2,'SampleRate',fsi2) %  max sample rate= 1.25e6/32
                        set(ai2,'SamplesPerTrigger', frame_length)
                        set(ai2.Channel,'InputRange',inrange);% default is [-5,5]
                        set(ai2,'TriggerType','HwDigital');  % falling edge
                    end
                    if ~isempty(save_chs_3)
                        delete(ai3)
                        ai3 = analoginput('nidaq',3);
                        set(ai3,'InputType','SingleEnded');
                        addchannel(ai3,ch_array(ich,:));  % we only add the channels we need
                        set(ai3,'SampleRate',fsi3) %  max sample rate= 1.25e6/32
                        set(ai3,'SamplesPerTrigger', frame_length)
                        set(ai3.Channel,'InputRange',inrange);% default is [-5,5]
                        set(ai3,'TriggerType','HwDigital');  % falling edge
                    end
                    if ~isempty(save_chs_4)
                        delete(ai4)
                        ai4 = analoginput('nidaq',4);
                        set(ai4,'InputType','SingleEnded');
                        addchannel(ai4,ch_array(ich,:));  % we only add the channels we need
                        set(ai4,'SampleRate',fsi4) %  max sample rate= 1.25e6/32
                        set(ai4,'SamplesPerTrigger', frame_length)
                        set(ai4.Channel,'InputRange',inrange);% default is [-5,5]
                        set(ai4,'TriggerType','HwDigital');  % falling edge
                    end
                    %%%%%   gradually raise signal for abituation    %%%%%
                    wait_time= length(TestSound{isig,1})/fso;
                    for iii=1: 7
                        for speaker_ind= 1: nspeaker_play
                            speaker= speaker_play_list(speaker_run,speaker_ind);
                            putvalue(dio.Line(2:4), speaker-1) % index the multiplexer. no need to convert to digital and write it backwards
                            putdata(ao, iii/7*ch_eq(speaker)* TestSound{isig,1} );
                            start([ao]);
                            putvalue(dio.Line(1), 0); % falling edge gives trigger
                            wait(ao,wait_time+2) % wait til stop or timeout
                            putvalue(dio.Line(1), 1);
                        end
                    end

                    %%%%% now put out real signal and record %%%%%%
                    for ich=1: nch_array % sample of ch groups
                        nch= size(ch_array,2);     offch= (ich-1)*nch;
                        %===================  save parameters ===============================================
                        for speaker_ind= 1: nspeaker_play
                            speaker= speaker_play_list(speaker_run,speaker_ind);
                            if ~isempty(save_chs_1),
                                for iiii=1:nch, NativeSca1{1,isig}(offch+iiii,speaker_ind)= ai1.Channel.NativeScaling(iiii); end
                                for iiii=1:nch, NativeOff1{1,isig}(offch+iiii,speaker_ind)=  ai1.Channel.NativeOffset(iiii); end
                                for iiii=1:nch, InputRan1{1,isig}(offch+iiii,speaker_ind,:)= ai1.Channel.InputRange(iiii); end
%                                 disp(['ch set: ', int2str(ich), 'Input Channel card 1:']), squeeze( InputRange1{1,isig}(offch+[1:nch],speaker_ind,:))
                            end
                            if ~isempty(save_chs_2),
                                for iiii=1:nch, NativeSca2{1,isig}(offch+iiii,speaker_ind)= ai2.Channel.NativeScaling(iiii); end
                                for iiii=1:nch, NativeOff2{1,isig}(offch+iiii,speaker_ind)=  ai2.Channel.NativeOffset(iiii); end
                                for iiii=1:nch, InputRan2{1,isig}(offch+iiii,speaker_ind,:)= ai2.Channel.InputRange(iiii); end
%                                 disp(['ch set: ', int2str(ich), 'Input Channel card 2:']), squeeze( InputRange2{1,isig}(offch+[1:nch],speaker_ind,:))
                            end
                            if ~isempty(save_chs_3),
                                for iiii=1:nch, NativeSca3{1,isig}(offch+iiii,speaker_ind)= ai3.Channel.NativeScaling(iiii); end
                                for iiii=1:nch, NativeOff3{1,isig}(offch+iiii,speaker_ind)=  ai3.Channel.NativeOffset(iiii); end
                                for iiii=1:nch, InputRan3{1,isig}(offch+iiii,speaker_ind,:)= ai3.Channel.InputRange(iiii); end
%                                 disp(['ch set: ', int2str(ich), 'Input Channel card 3:']), squeeze( InputRange3{1,isig}(offch+[1:nch],speaker_ind,:))
                            end
                            if ~isempty(save_chs_4),
                                for iiii=1:nch, NativeSca4{1,isig}(offch+iiii,speaker_ind)= ai4.Channel.NativeScaling(iiii); end
                                for iiii=1:nch, NativeOff4{1,isig}(offch+iiii,speaker_ind)=  ai4.Channel.NativeOffset(iiii); end
                                for iiii=1:nch, InputRan4{1,isig}(offch+iiii,speaker_ind,:)= ai4.Channel.InputRange(iiii); end
%                                 disp(['ch set: ', int2str(ich), 'Input Channel card 4:']), squeeze( InputRange4{1,isig}(offch+[1:nch],speaker_ind,:))
                            end
                        end
                        %====== end =========  save parameters ========================================

                        for iii=1: nreps
                            for speaker_ind= 1: nspeaker_play
                                speaker= speaker_play_list(speaker_run,speaker_ind);
                                putvalue(dio.Line(2:4), speaker-1) % index the multiplexer. no need to convert to digital and write it backwards
                                % queue data for output
                                % we play long silence to work as a timer
                                putdata(ao, ch_eq(speaker)* TestSound{isig,1} ); % equalize magnitude
                                %send speaker output and record data from microphone
                                start(ao);
                                if ~isempty(save_chs_1), start(ai1); end
                                if ~isempty(save_chs_2), start(ai2); end
                                if ~isempty(save_chs_3), start(ai3); end
                                if ~isempty(save_chs_4), start(ai4); end
                                putvalue(dio.Line(1), 0); % falling edge gives trigger

                                % aquiring the data
                                wait(ao,wait_time+2) % wait til stop or timeout in 2 sec
                                if ~isempty(save_chs_1), wait(ai1,2), end
                                if ~isempty(save_chs_2), wait(ai2,2), end
                                if ~isempty(save_chs_3), wait(ai3,2), end
                                if ~isempty(save_chs_4), wait(ai4,2), end

                                % record selected channels:
                                off0= (iii-1)*frame_length;
                                if ~isempty(save_chs_1)
                                    Data1{1,isig}(off0+ [1:frame_length],offch+[1:nch],speaker_ind)= getdata(ai1,frame_length, data_type);
                                end
                                if ~isempty(save_chs_2)
                                    Data2{1,isig}(off0+ [1:frame_length],offch+[1:nch],speaker_ind)= getdata(ai2,frame_length, data_type);
                                end
                                if ~isempty(save_chs_3)
                                    Data3{1,isig}(off0+ [1:frame_length],offch+[1:nch],speaker_ind)= getdata(ai3,frame_length, data_type);
                                end
                                if ~isempty(save_chs_4)
                                    Data4{1,isig}(off0+ [1:frame_length],offch+[1:nch],speaker_ind)= getdata(ai4,frame_length, data_type);
                                end
                                % restore trigger line to 1
                                putvalue(dio.Line(1), 1);
                            end % ----- for speaker_ind= 1: nspeaker_play
                        end  % ----- for iii=1: nreps
 
                        if ich<nch_array % get cards programmed for next run
                            if ~isempty(save_chs_1)
                                %                                     delet
                                %                                     e(ai1)
                                ai1 = analoginput('nidaq',1);
                                set(ai1,'InputType','SingleEnded');
                                addchannel(ai1,ch_array(ich+1,:));  % we only add the channels we need
                                set(ai1,'SampleRate',fsi1) %  max sample rate= 1.25e6/32
                                set(ai1,'SamplesPerTrigger', frame_length)
                                set(ai1.Channel,'InputRange',inrange);% default is [-5,5]
                                set(ai1,'TriggerType','HwDigital');  % falling edge
                            end

                            if ~isempty(save_chs_2)
                                %                                     delete(ai2)
                                ai2 = analoginput('nidaq',2);
                                set(ai2,'InputType','SingleEnded');
                                addchannel(ai2,ch_array(ich+1,:));  % we only add the channels we need
                                set(ai2,'SampleRate',fsi2) %  max sample rate= 1.25e6/32
                                set(ai2,'SamplesPerTrigger', frame_length)
                                set(ai2.Channel,'InputRange',inrange);% default is [-5,5]
                                set(ai2,'TriggerType','HwDigital');  % falling edge
                            end
                            if ~isempty(save_chs_3)
                                %                                     delete(ai3)
                                ai3 = analoginput('nidaq',3);
                                set(ai3,'InputType','SingleEnded');
                                addchannel(ai3,ch_array(ich+1,:));  % we only add the channels we need
                                set(ai3,'SampleRate',fsi3) %  max sample rate= 1.25e6/32
                                set(ai3,'SamplesPerTrigger', frame_length)
                                set(ai3.Channel,'InputRange',inrange);% default is [-5,5]
                                set(ai3,'TriggerType','HwDigital');  % falling edge
                            end

                            if ~isempty(save_chs_4)
                                %                                     delete(ai4)
                                ai4 = analoginput('nidaq',4);
                                set(ai4,'InputType','SingleEnded');
                                addchannel(ai4,ch_array(ich+1,:));  % we only add the channels we need
                                set(ai4,'SampleRate',fsi4) %  max sample rate= 1.25e6/32
                                set(ai4,'SamplesPerTrigger', frame_length)
                                set(ai4.Channel,'InputRange',inrange);% default is [-5,5]
                                set(ai4,'TriggerType','HwDigital');  % falling edge
                            end

                        end %-------- if ich<nch_array
                    end  % ----  for ich=1: nch_array  -------: sets of microphones to achieve high sampling

                    wait(ao,1)

                    % -------------------------- Display --------------------------------------------
                    if ~isempty(save_chs_1)
                        NativeScaling = get(ai1.Channel(save_chs_1(1)),'NativeScaling'); % Use only 1 channel if all are set to the same range %***
                        NativeOffset = get(ai1.Channel(save_chs_1(1)),'NativeOffset'); % Use only 1 channel if all are set to the same range %***
                        %                                 figure(1), subplot(2,2,1), plot(double(Data1{1,isig}(1:5:end,:))*NativeScaling + NativeOffset), title(box_label_str(1,:)), aaa= axis; axis([aaa(1:2),  inrange])
                        Data_zoom= double(Data1{1,isig}(display_range,:))*NativeScaling + NativeOffset;
                        figure(2), subplot(2,2,1), plot(Data_zoom), title(box_label_str(1,:)), aaa= axis; %axis([1,320, aaa(3:4)])
                    end
                    if ~isempty(save_chs_2)
                        NativeScaling = get(ai2.Channel(save_chs_2(1)),'NativeScaling'); % Use only 1 channel if all are set to the same range
                        NativeOffset = get(ai2.Channel(save_chs_2(1)),'NativeOffset'); % Use only 1 channel if all are set to the same range
                        %                                 figure(1), subplot(2,2,2), plot(double(Data2{1,isig}(1:5:end,:))*NativeScaling + NativeOffset), title(box_label_str(2,:)), aaa= axis; axis([aaa(1:2),  inrange])
                        Data_zoom= double(Data2{1,isig}(display_range,:))*NativeScaling + NativeOffset;
                        figure(2), subplot(2,2,2), plot(Data_zoom), title(box_label_str(2,:)), aaa= axis;
                    end
                    if ~isempty(save_chs_3)
                        NativeScaling = get(ai3.Channel(save_chs_3(1)),'NativeScaling'); % Use only 1 channel if all are set to the same range
                        NativeOffset = get(ai3.Channel(save_chs_3(1)),'NativeOffset'); % Use only 1 channel if all are set to the same range
                        %                                 figure(1), subplot(2,2,3), plot(double(Data3{1,isig}(1:5:end,:))*NativeScaling + NativeOffset), title(box_label_str(3,:)), aaa= axis; axis([aaa(1:2),  inrange])
                        Data_zoom= double(Data3{1,isig}(display_range,:))*NativeScaling + NativeOffset;
                        figure(2), subplot(2,2,3), plot(Data_zoom), title(box_label_str(3,:)), aaa= axis;
                    end
                    if ~isempty(save_chs_4)
                        NativeScaling = get(ai4.Channel(save_chs_4(1)),'NativeScaling'); % Use only 1 channel if all are set to the same range
                        NativeOffset = get(ai4.Channel(save_chs_4(1)),'NativeOffset'); % Use only 1 channel if all are set to the same range
                        %                                 figure(1), subplot(2,2,4), plot(double(Data4{1,isig}(1:5:end,:))*NativeScaling + NativeOffset), title(box_label_str(4,:)), aaa= axis; axis([aaa(1:2),  inrange])
                        Data_zoom= double(Data4{1,isig}(display_range,:))*NativeScaling + NativeOffset;
                        figure(2), subplot(2,2,4), plot(Data_zoom), title(box_label_str(4,:)), aaa= axis;
                    end
                    drawnow
                    figure(1), hold off, figure(2), hold off
                    % end  --------------------- Display --------------------------------------------

                end %----- for isig=1:nsig --------------------------


                %--------------------------------------------------------------------
                %%%%%%%%%%%%%%%%% SAVE DATA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % Save Data into corresponding file: filename=
                % azimuth_elevation
                
                pause(0.2)
                tmp1= Data1; clear Data1;
                tmp2= Data2; clear Data2;
                tmp3= Data3; clear Data3;
                tmp4= Data4; clear Data4;

                for speaker_ind= 1: nspeaker_play % no. of speakers that play interleaved
                    % extract and save corresponding loudspeaker
                    speaker= speaker_play_list(speaker_run,speaker_ind);
                    Data1= cell(size(tmp1));  Data2= cell(size(tmp1)); Data3= cell(size(tmp1)); Data4= cell(size(tmp1));
                    for isig=1:nsig, Data1{1,isig}= tmp1{1,isig}(:,:,speaker_ind); end
                    for isig=1:nsig, Data2{1,isig}= tmp2{1,isig}(:,:,speaker_ind); end
                    for isig=1:nsig, Data3{1,isig}= tmp3{1,isig}(:,:,speaker_ind); end
                    for isig=1:nsig, Data4{1,isig}= tmp4{1,isig}(:,:,speaker_ind); end
                    elstr= ang2str(hoopelvn(i));
                    azstr= ang2str(speaker_array(n,speaker));
                    disp(['speaker=  ', int2str(speaker),  '  el= ', int2str( hoopelvn(i) ), ' az= ' ,  azstr ])

                    disp('data being saved.....')
                    filestr= [dirstr,'\A',azstr,'E',elstr];
                    display('.....press any key to continue .......')
                    pause
                    ok_flag=0; dd= dir([filestr,'.mat']); eval('err_fil=dd.name;', 'ok_flag=1;');
                    if ok_flag|overwrite_flag
                        save(filestr, 'Data1', 'Data2', 'Data3', 'Data4','-v6'); disp('done')
                    else
                        error(['file ', err_fil, ' already exixts. Please clear directories and type ''return''!!!'])
                        keyboard
                    end
                end  % ------  for speaker_ind=1: nspeaker_play
                
                % extract scaling for each loudspeaker (if playing
                % interleaved) or one loudspaker (at the current position)
                for speaker_ind= 1: nspeaker_play % no. of speakers that play interleaved
                    % extract and save corresponding loudspeaker
                    speaker= speaker_play_list(speaker_run,speaker_ind);
                    for isig=1:nsig,  
                        NativeScaling1{1,isig}= [NativeScaling1{1,isig}, NativeSca1{1,isig}(:,speaker_ind)]; 
                        NativeOffset1{1,isig}= [NativeOffset1{1,isig}, NativeOff1{1,isig}(:,speaker_ind)]; 
                        InputRange1{1,isig}= [InputRange1{1,isig}, InputRan1{1,isig}(:,speaker_ind,:)]; 
                        
                        NativeScaling2{1,isig}= [NativeScaling2{1,isig}, NativeSca2{1,isig}(:,speaker_ind)]; 
                        NativeOffset2{1,isig}= [NativeOffset2{1,isig}, NativeOff2{1,isig}(:,speaker_ind)]; 
                        InputRange2{1,isig}= [InputRange2{1,isig}, InputRan2{1,isig}(:,speaker_ind,:)]; 
                        
                        NativeScaling3{1,isig}= [NativeScaling3{1,isig}, NativeSca3{1,isig}(:,speaker_ind)]; 
                        NativeOffset3{1,isig}= [NativeOffset3{1,isig}, NativeOff3{1,isig}(:,speaker_ind)]; 
                        InputRange3{1,isig}= [InputRange3{1,isig}, InputRan3{1,isig}(:,speaker_ind,:)]; 
                        
                        NativeScaling4{1,isig}= [NativeScaling4{1,isig}, NativeSca4{1,isig}(:,speaker_ind)]; 
                        NativeOffset4{1,isig}= [NativeOffset4{1,isig}, NativeOff4{1,isig}(:,speaker_ind)]; 
                        InputRange4{1,isig}= [InputRange4{1,isig}, InputRan4{1,isig}(:,speaker_ind,:)]; 
                    end
                end  % ------  for speaker_ind=1: nspeaker_play
                
            end  % ----- for speaker_run=1: size(speaker_play_list,1)
            clear tmp1 tmp2 tmp3 tmp4
        end  % ----- for i= 1:nhoopelvn
    end
    speaker_play_flag= 0; % reset flag
end % end { n= 1:nspeaker_array)


% to recover double data from native type use: datadouble = double(nativedata)*daqhwinfo_ai1.NativeDataType + daqhwinfo_ai1.NativeOffset;

disp(['Done with data collection! ... saving parameters in ', dirstr])
eval(['save ',dirstr,'\param data_type elc azc highsamp_flag speaker_alternate_flag ch_array fsi1 fsi2 fsi3 fsi4 fso nreps nsilence frame_length dc_value save_chs_1 save_chs_2 save_chs_3 save_chs_4 signal_str TestSound ch_eq ch_fac speaker_array inrange box_label_str inform overwrite_flag NativeScaling1 NativeOffset1 InputRange1  NativeScaling2 NativeOffset2 InputRange2  NativeScaling3 NativeOffset3 InputRange3 NativeScaling4 NativeOffset4 InputRange4',' -v6'])

% clean up
delete(ao); delete(dio); %RTSIClockDisconnect
delete(ai1);delete(ai2);delete(ai3);delete(ai4);
clear ao dio ai1 ai2 ai3 ai4

