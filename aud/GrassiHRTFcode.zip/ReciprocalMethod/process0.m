% Time averaging of pulses. Abnormal pulses will be discarded
% Elena Grassi feb 22/06
addpath('..\');
% check matlab version. If matlab 7, save variables with v6 compatibility
tmp= ver;  ver_str= tmp(1).Release; if ver_str(1:4)=='(R13', save_option_str= ''; else,  save_option_str= ' -v6'; end

dirstr= 'c:\Rec_setup_data\dat'; azcv=   [1,2, 3,4 ].'; %%%left and right speaker  April 12/06 calibration with better sweep signal and preemphasis preemph_upsweep_800to18000_98pts_at_39063 (old one had bad response over 10 khz). Speakers left and right. and longer rest period

eval(['load ', dirstr,'\param data_type elc azc fsi1 fsi2 fsi3 fsi4 fso nreps nsilence frame_length dc_value save_chs_1 save_chs_2 save_chs_3 save_chs_4 signal_str TestSound ch_eq ch_fac speaker_array inrange  box_label_str inform overwrite_flag NativeScaling1 NativeOffset1 InputRange1 NativeScaling2 NativeOffset2 InputRange2 NativeScaling3 NativeOffset3 InputRange3 NativeScaling4 NativeOffset4 InputRange4 '])

if (fsi1~=fsi2)|(fsi2~=fsi3)|(fsi3~=fsi4), error(' channels have different sampling frequencies'), else, fsi= fsi1; end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ndelay= 5; % time when no signal should arrive yet 
% we must account for the length of impulse response (about 2ms) and the max time delay (about 70 usec), so the number of points we want to save for each pulse is longer than sounds being played. We may even  save a much longer record to chop it later on. (recall: nsweep= 300; nprbs= 127*clock_per; nnoise=300; ntone=800 
pulse_npts= frame_length-ndelay; % points of pulse that whish to keep
npos= length(azc); 
nch1= length(save_chs_1); nch2= length(save_chs_2); 
nch3= length(save_chs_3); nch4= length(save_chs_4); 
nch= nch1+nch2+nch3+nch4;% number of channels
% Retrieve number of signals:---------------------
elstr= ang2str(elc(1));  azstr= ang2str(azc(1));  filestr= [dirstr,'\A',azstr,'E',elstr];  % filestr= [dirstr,'A',azstr,'\A',azstr,'E',elstr]; 
eval(['load ', filestr, ' Data1 ']); 
nsig= size(Data1,2); 
%---------------------------------------------------
NSc=cell(1,nsig); NOff=cell(1,nsig);
for ii=1:nsig
    if ~isempty(save_chs_1),
        NSc{1,ii}= [NSc{1,ii}; NativeScaling1{1,ii}];
        NOff{1,ii}= [NOff{1,ii}; NativeOffset1{1,ii}];
    end
    if ~isempty(save_chs_2),
        NSc{1,ii}= [NSc{1,ii}; NativeScaling2{1,ii}];
        NOff{1,ii}= [NOff{1,ii}; NativeOffset2{1,ii}];
    end
    if ~isempty(save_chs_3),
        NSc{1,ii}= [NSc{1,ii}; NativeScaling3{1,ii}];
        NOff{1,ii}= [NOff{1,ii}; NativeOffset3{1,ii}];
    end
    if ~isempty(save_chs_4),
        NSc{1,ii}= [NSc{1,ii}; NativeScaling4{1,ii}];
        NOff{1,ii}= [NOff{1,ii}; NativeOffset4{1,ii}];
    end
end

% % % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define bandpass filter 
f_low= 700; f_high= 15000  
filter_str= '[b,a]= butter(2,2/fsi1*[f_low,f_high]);'; 
eval(filter_str);
% % % %---------------------------------------------------
% f_low= []; f_high= []; % meaning no filter is applied 

av_p= cell(1,nsig); % averaged pulses
for i=1: nsig, av_p{1,i}= zeros(pulse_npts,npos,nch); end % for each signal there is a 3-D matrix. npos: left or right, nch: microphones
good_pulses_cnt= cell(1,nsig); 
for i=1: nsig, good_pulses_cnt{1,i}= zeros(npos,nch); end 

tmp= zeros(frame_length,nreps); % temporal matrix to hold individual pulses
tmp1= zeros(pulse_npts,nreps); % temporal matrix to hold individual pulses after initial points are removed 
tmp_av=  zeros(pulse_npts, 1);

for i=1:npos % number of loudspeaker positions
    disp(' *************************************')
    disp([i, elc(i), azc(i)]) 
    elstr= ang2str(elc(i));
    azstr= ang2str(azc(i));
    filestr= [dirstr,'\A',azstr,'E',elstr];   %  filestr= [dirstr,'A',azstr,'\A',azstr,'E',elstr]; 
    
    eval(['load ', filestr, ' Data1 Data2 Data3 Data4']); 
    ii_ind=[]; % index of signals that are present (non-empty Data)
    for ii=1:nsig % number of signals
        % concatenate all channels in 1 Data variable
        Data= [Data1{1,ii}, Data2{1,ii},Data3{1,ii}, Data4{1,ii}]; 
%         NativeScaling= NSc{1,ii}(:,i); NativeOffset= NOff{1,ii}(:,i);
NativeScaling=NativeScaling1{1,1}; NativeOffset=NativeOffset1{1,1};
        if ~isempty(Data)
            ii_ind=[ii_ind; ii];
            for iii=1:nch % number of channels 
                if data_type(1)=='n', % native 
%                     tmp(:)= double(Data(1:frame_length*nreps,iii))*NativeScaling(iii) + NativeOffset(iii); 
                    tmp(:)= double(Data(1:frame_length*nreps,iii))*NativeScaling(1) + NativeOffset(1); 
                else
                    tmp(:)= Data( 1:frame_length*nreps,iii);   % put each pulse in a column of tmp1 matrix
                end
                % remove initial pts
                tmp1= tmp(ndelay+1:end, :);

                % detrend and filter
                tmp1= detrend(tmp1);  % figure(1), clf, plot(tmp1(1:600,:)), hold on, h= plot(mean(tmp1(1:600,:).').','--k'); hold off, set(h,'LineWidth',2)
                % figure(2), clf, fsc=fsi/256*(0:256-1); xxx=mean(tmp1(72:155,:).').'; plot(fsc,abs(fft(tmp1(80:155,:),256))), hold on , h=plot(fsc,abs(fft(xxx,256)),'--k'), hold off, set(h,'LineWidth',2)
                % figure(2), clf, fsc=fsi/256*(0:256-1); xxx=mean(tmp1(85:214,:).').'; plot(fsc,abs(fft(tmp1(75:220,:),256))), hold on , h=plot(fsc,abs(fft(xxx,256)),'--k'), hold off, set(h,'LineWidth',2)
                % figure(2), clf, fsc=fsi/256*(0:256-1); xxx=mean(tmp1(150:365,:).').'; plot(fsc,abs(fft(tmp1(150:365,:),256))), hold on , h=plot(fsc,abs(fft(xxx,256)),'--k'), hold off, set(h,'LineWidth',2)
                % figure(2), clf, fsc=fsi/512*(0:512-1); xxx=mean(tmp1(75:220,:).').'; plot(fsc,abs(fft(tmp1(75:220,:),512))), hold on , h=plot(fsc,abs(fft(xxx,512)),'--k'), hold off, set(h,'LineWidth',2)
                % figure(2), clf, fsc=fsi/512*(0:512-1); xxx=mean(tmp1(175:515,:).').'; plot(fsc,abs(fft(tmp1(175:515,:),512))), hold on , h=plot(fsc,abs(fft(xxx,512)),'--k'), hold off, set(h,'LineWidth',2)
                % figure(2), clf, fsc=fsi/512*(0:512-1); xxx=mean(tmp1(150:400,:).').'; plot(fsc,abs(fft(tmp1(150:400,:),512))), hold on , h=plot(fsc,abs(fft(xxx,512)),'--k'), hold off, set(h,'LineWidth',2)
                if ~isempty(f_high), tmp1= filtfilt(b,a, tmp1);  end % to match initial conditions, square mag

                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % discard noisy pulses here:
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           tmp1= tmp(ndelay+1:end,:);
                % compare each raw pulse with its clean average
                tmp_av=  mean(tmp1.').';  
                good_pulse= ones(1, nreps); 
                k1= 0.25*max([abs(tmp_av);0.1]); % use 20% criterion for large signals, or fixed threshold for small signals were the cuantification error is bigger
                for iiii=1:nreps
                    if max( abs( tmp1(:,iiii)- tmp_av)) > k1  
%                         disp(['removed pulse ', int2str(iiii), ' in signal= ', int2str(ii), ' , position= ', int2str(i), ', channel= ', int2str(iii)])
                        % keyboard, % for ix= 1:nreps, plot( abs( tmp1(:,ix)- tmp_av) ), hold on,  plot( abs(tmp_av), 'r' ), hold off, title(int2str(ix)), pause, end
                        tmp1(:,iiii)= zeros(pulse_npts,1); % eliminate pulse
                        good_pulse(iiii)= 0; 
                    end
                end
                if ~all(good_pulse==1), ind= find(~good_pulse);
                    disp(['removed pulse: ', int2str(ind), ' , in signal= ', int2str(ii), ' , position= ', int2str(i), ', channel= ', int2str(iii)])
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % compute average
                av_p{1,ii}(:,i,iii)= ( sum(tmp1.').')./ sum(good_pulse);  %{signal ii}(time:, position i, channel iii)
                good_pulses_cnt{1,ii}(i,iii)=  sum(good_pulse);
                
            end
        else, disp(['****WARNING****: signal ', int2str(ii), ' is not present ****'])
        end
    end
end

av_p= av_p(1,ii_ind); good_pulses_cnt= good_pulses_cnt(1,ii_ind); %keep only signals that are present
eval(['save ', dirstr,'\avpulses av_p good_pulses_cnt elc azc frame_length ndelay fsi f_low f_high filter_str speaker_array inform', save_option_str]) 
