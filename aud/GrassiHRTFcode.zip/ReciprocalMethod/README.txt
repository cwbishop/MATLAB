5/10/2006
From Elena Grassi egrassi@umd.edu
To Lee Miller

The code I'm emailing you comes with a caviat. It is for a reciprocal setup, in which the loudspeaker in in the ear and the microphones outside. I know, this is not the most ideal but there are few things that can still be useful to you regarding the format in which I read the variables in matlab (native) assuming your hardware supports it. 
The signal processing is still pretty much the same. The signal that is being used has to be tailored a bit to your setup (in duration, frequency content: if your loudspeakers are lousy you may have to do preemphsis etc) This is the reason I'm not including the current signal, it's too specific to my setup. 

I will try to dig out the old signals for you because they are likely to be more useful for the direct setup and possibly if I find a decent version, the code for the acquisition with the direct setup.
