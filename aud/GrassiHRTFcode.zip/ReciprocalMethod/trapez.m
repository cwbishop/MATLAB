function window= trapez(N,r,d);
% function window= trapez(N,rise);
% N= number of points;
% r= rise, fraction of total number of points for the slope to rise
% d= decay,  fraction of total number of points for the slope to decay

if nargin<3, d=r; end
nrise= round(r*N); ndecay= round(d*N);
window= ones(N,1);
for i=1:nrise, window(i)=(i-1)/nrise; end
for i=1:ndecay, ii= N-i+1; window(ii)= (i-1)/ndecay; end
