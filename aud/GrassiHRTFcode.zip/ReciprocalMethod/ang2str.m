function az2str= az2str(az)
% azimuth to string conversion
aaz= abs(az);  
if aaz<100&aaz>=10, zstr='0';
elseif aaz<10&aaz>=0, zstr='00';
else zstr='';
end
if az<0, az2str= ['n',zstr,int2str(aaz)];
else,  az2str= ['p',zstr,int2str(aaz)];
end
