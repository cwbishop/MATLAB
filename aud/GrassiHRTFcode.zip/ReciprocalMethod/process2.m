%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Low and High freq approximation and impulse responses
% After we have smoothed the HRTFs within the valid range, we need to extrapolate
% them in a physically sensible way and to convert them 
% to impulse responses. The high frequencies will be tapered down to zero with a 
% homemade window that preserves the original noisy phase information.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Elena Grassi Oct 3/05: Modified to select different low frequency approximations: before low freq was approximated to time delay
% now we can chose to make it go to zero.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tmp= ver;  ver_str= tmp(1).Release; if ver_str(1:4)=='(R13', save_option_str= ''; else,  save_option_str= ' -v6'; end
dirstr=  'c:\Rec_Setup_data\dat'; 

ij= sqrt(-1);
LF_approx_method= 'zero'; %  'zero': hanning window to zero; 'time_delay': approximates to a pure time delay obtained from a threshold detection on the timeaveraged pulses (see dp4)
freq_smoothing_fac= 0.08; % the smaller the more smoothing. Around 0.05 to 0.1  seems to be adecuate 

% load the averaged and smoothed  HRTF. These HRTF are only from 1:(NN/2+1)=NN2
%**eval(['load ', dirstr, 'HRTF**f*** HRTF freq_smoothing sig_frac inform n0r n1r applied_del put_back_delay_flag_in_dp5 elc azc nsignal nch npos f_v NN NN2 fsi df fscale fscale_o speaker_array f_low f_high f_low_dp5 f_high_dp5 ndelay frame_length pulse_npts trapez_w_decay_r trapez_w_decay_s ']);
%***load HRTF instead of HRTFf to bypass smoothing
eval(['load ', dirstr, '\HRTF HRTF inform n0r n1r n0s n1s elc azc nsig nch npos  NN NN2 fsi df fscale  speaker_array f_low f_high ndelay frame_length pulse_npts trapez_w_decay_r trapez_w_decay_s freq_sm']);
freq_smoothing= freq_smoothing_fac*3000*83333/(NN*fsi),  %*** 0.5= 1/4 sampling freq. % 0.05 seems to be adequate when using NN=3000 pts @ 83 ksamp/sec. if NN is smaller, smoothing may not be needed.

% see figure 1 and 2 (for fig 2 set f1= 2500;)
nsig= size(HRTF,2) ;
nfreq= size(HRTF{1,1},1);
npos= size(HRTF{1,1},2);
nch= size(HRTF{1,1},3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Let's start with the high freq fix first
% f01= 14000; f02= 17000 % window decay: start and end freq
f01= 12000; f02= 16000 % window decay: start and end freq
nf01= min(find(fscale>=f01)), fscale(nf01)
nf02= min(find(fscale>=f02)), fscale(nf02)
if isempty(nf02), error('empty frequency nf02'), end
nwin= nf02- nf01;
% roll off high freq using: 

win= blackman(2*nwin); % this one goes to zero
win= [ones(nf01,1); win(nwin+1:end)]; 
n= length(win); win = [win; zeros(nfreq-n,1)];
for ii=1:nsig %  HRTF{1, signal ii} (freq:, position i, channel iii)
    for iii=1:nch % number of channels
        for i=1:npos,
            HRTF{1,ii}(:,i,iii)= HRTF{1,ii}(:,i,iii).*win;  
        end
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Let's do the Low freq fix now:
f00= 1600; % frequency to start approximation. HRTFs above this freq are intact
nf00= min(find(fscale>=f00)), fscale(nf00)
f000= 900; % HRTF below this frequency is zero.
nf000= min(find(fscale>=f000)), fscale(nf000)

nwin= nf00- nf000;
% roll off high freq using: 
win= blackman(nwin*2); % this one goes to zero
win= [zeros(nf000-1,1); win(1:nwin)]; 
n= length(win); win = [win; ones(nfreq-n,1)];

for ii=1:nsig %  HRTF{1, signal ii} (freq:, position i, channel iii)
    for iii=1:nch % number of channels
        for i=1:npos,
            HRTF{1,ii}(:,i,iii)= HRTF{1,ii}(:,i,iii).*win;
        end
    end
end

%%% Smooth with linear filter %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% should smooth absolute value: Smaller than 0.2 tends to reduce too much the amplitude, because the real and imag part are sinusoid like and change fairly fast.
if freq_smoothing<1,
    [b,a]= butter( 4, freq_smoothing);%***0.5= 1/4 sampling freq: 0.1 is the adequate frequency smoothing when using NN=3000 pts and freq=83333.  Determine
    tmp= cell(1,nsig); for ii=1:nsig, tmp{1,ii}= zeros(size(HRTF{1,ii})); end
    for ii=1:nsig %%*** for now, smooth only  broadband sweep, prbs, noise, impulse
        for iii=1:nch % number of channels
            for i= 1:npos
                abs_HRTF= abs(HRTF{1,ii}(:,i,iii)); ph_HRTF=  angle(HRTF{1,ii}(:,i,iii));
%               %***  abs_HRTF=  filtfilt(b,a, abs_HRTF);
                abs_HRTF=  filter(b,a, abs_HRTF);
                tmp{1,ii}(:,i,iii) =  cos(ph_HRTF).*abs_HRTF + ij* sin(ph_HRTF).*abs_HRTF;
            end
        end
    end
    for ii=1:nsig, HRTF{1,ii}= tmp{1,ii}; end
end
eval(['save ', dirstr, '\HRTFfx HRTF  freq_smoothing  inform  f000 f00 f01 f02 n0r n1r  elc azc nsig nch npos NN NN2 fsi df fscale  speaker_array f_low f_high   ndelay frame_length pulse_npts trapez_w_decay_r trapez_w_decay_s ', save_option_str]);



figure(1), clf, 
for ii=1:nsig,
    for iii=1:nch
        semilogy(fscale, abs(HRTF{1,ii}(:,:,iii))), hold on, semilogy(fscale, abs(HRTF{1,ii}(:,:,iii)),'*'), hold off
        axis ([500,16000, 0.01,10])
        title([' sig= ', int2str(ii), ', ch= ', int2str(iii)]), pause
    end
end


