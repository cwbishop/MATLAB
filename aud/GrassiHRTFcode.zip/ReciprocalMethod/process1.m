% User need to specify number of points to chop pulses according the length of the test signals
% Use this when reference signals are measured with one microphone per each
% sphere point.
% EG 2003
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tmp= ver;  ver_str= tmp(1).Release; if ver_str(1:4)=='(R13', save_option_str= ''; else,  save_option_str= ' -v6'; end

% Compute the HRTFs (HRTF.mat) 
ij= sqrt(-1);
trapez_w_decay_r= 0.03; % slope of trapezoidal window for reference (fraction of total number of points)
trapez_w_decay_s= 0.03; % slope of trapezoidal window for signal (fraction of total number of points)


addpath('..\');
% averaged signal without time domain filtering:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dirstr=  'c:\Rec_Setup_data\dat'; NN=512; n0r= 144; n1r= 394; n0s= 138; n1s= 430; micdirstr= 'C:\Rec_Setup_data\dat_cal_preemph_upsweep_1000to15000_142pts_at_78125_2'
sig=1; %  upsweep, prbs,noise,impulse, downsweep

NN=NN % number of points for the fft
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load the conditioned averaged reference pulses 
eval(['load ', micdirstr,'\avpulses av_p good_pulses_cnt elc azc frame_length ndelay fsi f_low f_high speaker_array ']) 
% See Fig1
nsig= size(av_p,2) ;
pulse_npts= size(av_p{1,1},1); % time
npos= size(av_p{1,1},2); % number of loudspeaker positions (elc,azc pairs)
nch= size(av_p{1,1},3); 
% cut out pulses:
n0r= n0r, n1r= n1r
for ii=1:nsig
    av_p{1,ii}= av_p{1,ii}(n0r:n1r,:,:);   % averaged pulses {signal ii}(time:, position i, channel iii)
end
% See Fig1

N= n1r-n0r+1; % (ii,ch)
if max(max(N))>NN, error('reference signal will be truncated during fft'), end

%%%%%  Remove Mean from reference signal %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%***OR WE SHOULD RATHER FOCUS ON MAKING IT START AT 0!!!!:  take first 10 pts as baseline
for ii=1:nsig
    for i=1:npos
        for iii=1:nch
            av_p{1,ii}(:,i,iii)= detrend( av_p{1,ii}(:,i,iii)); 
        end
    end
end

% See Fig1

%%%%% Apply trapezoidal window to reference signal %%%%%%%%%%%%%%%%%%%%%%%%%%%%
for ii=1:nsig
    for i=1:npos
        for iii=1:nch
            av_p{1,ii}(:,i,iii)= av_p{1,ii}(:,i,iii).*trapez(N,0.01,trapez_w_decay_r);  %   av_p{1,sig}(:,i,1)  % av_p{1, signal ii} (time:, position i, channel iii)
        end
    end
end
% See Fig1

av_p_r= av_p; % averaged pulse reference
npos_r= npos;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load conditioned averaged pulses. Work with channel ch_i . This corresponds to reference miccali
eval(['load ', dirstr,'\avpulses av_p good_pulses_cnt elc azc frame_length ndelay fsi f_low f_high speaker_array inform']) 

freq_sm=  0.1*3000*83333/(NN*fsi)% determine freq smoothing, if >1 do not filter. 0.5= 1/4 sampling freq. 0.1 is the adequate frequency smoothing when using NN=3000 pts @ 83 ksamp/sec.. if NN is smaller, smoothing may not be needed.

nsig= size(av_p,2) ;
pulse_npts= size(av_p{1,1},1); % time
npos= size(av_p{1,1},2);
nch= size(av_p{1,1},3);

inform= strcat(inform, ' dp5: no delay manipulations');
%  cut signal 
n0s= n0s% leave some extra pts so the final IR is causal 
n1s= n1s  % beginning+signal duration+IR+ max_delay from ear separation. 
for ii=1:nsig
    av_p{1,ii}= av_p{1,ii}(n0s:n1s,:,:);   % averaged pulses {signal ii}(time:, position i, channel iii)
end
% See Fig1

N= n1s-n0s+1; % (ii,ch)
if max(max(N))>NN, error('reference signal will be truncated during fft'), end

%%%%%  Remove Mean from reference signal %%%%%%%%%%%%%%%%%%%%%%%%%%%%
for ii=1:nsig
    for i=1:npos
        for iii=1:nch
            av_p{1,ii}(:,i,iii)= detrend( av_p{1,ii}(:,i,iii)); 
        end
    end
end

% See Fig1

%%%%% Apply trapezoidal window to reference signal %%%%%%%%%%%%%%%%%%%%%%%%%%%%
for ii=1:nsig
    for i=1:npos
        for iii=1:nch
            av_p{1,ii}(:,i,iii)= av_p{1,ii}(:,i,iii).*trapez(N,0.01,trapez_w_decay_r);  %   av_p{1,sig}(:,i,1)  % av_p{1, signal ii} (time:, position i, channel iii)
        end
    end
end
% See Fig1

%%%%%%%%%%%%  Compute HRTFs  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% only half +1 (they can be recostructed by symmetry/antisymmetry.
dt= 1/fsi; df= fsi/NN; NN2= NN/2+1; fscale= df*[0:NN/2];
% % n=[0:NN2-1].'; % to generate the shift we need.

% Initialize
HRTF= cell(1,nsig); % HRTF{1, signal ii} (frequency, position i, channel iii)
for ii=1: nsig, HRTF{1,ii}= zeros(NN2,npos,nch); end; 

%******************************* filter before dividing by ref!!!! 
freq_sm
if freq_sm<1, [b,a]= butter( 2, freq_sm);
    disp('****** smoothing done before dividing by reference, time delay not put back! *************')
end %***0.5= 1/4 sampling

for ii=1:nsig
    for iii=1:nch % number of channels (microphones on sphere)
        for i=1:npos % av_p{1, signal ii} (time:, position i, channel iii)  i=find(azc==40&elc==-40) %
            i_r= mod(i,npos_r); if i_r==0, i_r= npos_r; end
            xs= av_p{1,ii}(:,i,iii);
            xr= av_p_r{1,ii}(:,i_r,iii);

            tmp= fft(xs,NN);  fft_s= abs(tmp); fft_s_ph= angle(tmp); 
            tmp= fft(xr,NN);  fft_r= abs(tmp); fft_r_ph= angle(tmp); 
            zero_clamp= mean(fft_r)*0.5e-2;
            if freq_sm<1, tmp= filtfilt(b,a, [ fft_s] )./max(filtfilt(b,a, [fft_r] ),zero_clamp); %***must be magnitude only!!!
            else,  tmp= fft_s./ max(fft_r, zero_clamp);
            end
            tmp= tmp(1:NN2);  %*** if any(tmp<0), disp('warning: negative magnitude after smoothing filter'), keyboard, end
            tmp_ph= fft_s_ph(1:NN2)-fft_r_ph(1:NN2);
            
            tmp= tmp.*cos(tmp_ph)+ ij* tmp.*sin(tmp_ph);  % reconstitute phase that was removed to do smoothing
%             HRTF{1,ii}(:,i,iii)= tmp;  
            
            HRTF{1,ii}(:,i,iii)= tmp(1:NN2);  if tmp(1:NN2)<0, disp('warning: negative magnitude after smoothing filter'), end
        end
    end
end
disp('**************************************************************************')
disp('**************************************************************************')
disp('**************************************************************************')


eval(['save ', dirstr, '\HRTF HRTF inform n0r n1r n0s n1s elc azc nsig nch npos  NN NN2 fsi df fscale  speaker_array f_low f_high ndelay frame_length pulse_npts trapez_w_decay_r trapez_w_decay_s freq_sm', save_option_str]);


