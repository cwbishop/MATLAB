%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Obtain impulse responses if HRTF is magnitude only the HRIR is automatically computed as min phase 
% If the HRTF is complex the user can still specify min_phase using the min_ph_flag=1; 
% Elena Grassi 2004
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tmp= ver;  ver_str= tmp(1).Release; if ver_str(1:4)=='(R13', save_option_str= ''; else,  save_option_str= ' -v6'; end
dirstr=  'c:\Rec_Setup_data\dat'; 

% Flags 
dtf_flag= 0 
min_ph_flag= 0; % use 1 when HRTFs are magnitude only or even if they are complex and we want min phase.

% load HRTFs after low and high freq fix
eval(['load ', dirstr, '\HRTFfx HRTF freq_smoothing inform f000 f00 f01 f02 n0r n1r elc azc nsig nch npos NN NN2 fsi df fscale speaker_array f_low f_high  ndelay frame_length pulse_npts trapez_w_decay_r trapez_w_decay_s ']);

    
nsig= size(HRTF,2) ;
nfreq= size(HRTF{1,1},1);
npos= size(HRTF{1,1},2);
nch= size(HRTF{1,1},3);

HRIR= cell(size(HRTF));
for ii=1:nsig,  HRIR{1,ii}= zeros(NN,npos,nch);  end

if dtf_flag % compute the mean HRTF (over all positions) to then normalize the HRTF's 
    meanHRTF= cell(size(HRTF));
    for i=1:nsig
        % If we want to compute the Directional Transfer Functions (DTF) we need to normalize by abs of the mean HRTF on each side
        meanHRTF{1,i} = mean(abs(HRTF{1,i}),2);
        ind= find(meanHRTF{1,i}<0.05); meanHRTF{1,i}(ind)=ones(size(meanHRTF{1,i}(ind)))*0.05;
    end
end

if ~(isreal(HRTF{1,1})|min_ph_flag) % complex HRTF and no min phase
    for ii=1:nsig
        for iii=1:nch % number of channels
            for i=1:npos,
                if ~(dtf_flag), tmp1= HRTF{1,ii}(:,i,iii);
                else, tmp1= HRTF{1,ii}(:,i,iii)./ meanHRTF{1,ii}(i,iii);
                end
                tmp= [ tmp1; [tmp1(NN2-1:-1:2).']' ];    
                HRIR{1,ii}(:,i,iii)= real(ifft(tmp)); % it should be real but because of numerics we need to discard small imag part
            end
        end
    end
else % if need to compute min_phase (either HRTF is mag only or user wants to get min_phase)
    l_min= [1; 2*ones( floor(NN/2)-1,1); ones(1 - rem(NN,2),1); zeros( floor(NN/2)-1,1)];
    min_ph_flag=1 % to save flag to indicate that we computed min phase
    
    if ~isreal(HRTF{1,1}),  for ii=1:nsig, HRTF{1,ii}= abs(HRTF{1,ii}); end, end
    for ii=1:nsig, ind= find(HRTF{1,ii}<1e-4); HRTF{1,ii}(ind)= 1e-4*ones(size(ind)); end
    for ii=1:nsig
        for iii=1:nch % number of channels
            for i=1:npos,
                if ~(dtf_flag), tmp1= HRTF{1,ii}(:,i,iii);
                else, tmp1= HRTF{1,ii}(:,i,iii)./ meanHRTF{1,ii}(i,iii);
                end
                tmp= [ tmp1; [tmp1(NN2-1:-1:2).']' ];    
                y1 = real(ifft(log(tmp)));
                HRIR{1,ii}(:,i,iii)= real(ifft(exp(fft(l_min.*y1)))); % it should be real but because of numerics we need to discard small imag part
            end
        end
    end
end


if dtf_flag==0, eval(['save ', dirstr, '\HRIR HRIR min_ph_flag dtf_flag freq_smoothing inform  f000 f00 f01 f02 n0r n1r  elc azc nsig nch npos  NN NN2 fsi df fscale  speaker_array f_low f_high   ndelay frame_length pulse_npts trapez_w_decay_r trapez_w_decay_s ', save_option_str]);
else, eval(['save ', dirstr, '\HRIR_dtf HRIR min_ph_flag dtf_flag freq_smoothing  inform f000 f00 f01 f02 n0r n1r  elc azc nsig nch npos  NN NN2 fsi df fscale  speaker_array f_low f_high ndelay frame_length pulse_npts trapez_w_decay_r trapez_w_decay_s ',save_option_str]);
end
