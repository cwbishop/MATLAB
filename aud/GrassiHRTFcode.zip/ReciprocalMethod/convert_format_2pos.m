% to conform 2 sets of data taken in different positions to one data set
% This must be runned before convert2server
% Elena Grassi March 2006

% converter to eserver format
% % % %   File is ASCII, one number per line. Sampling frequency is 44100 kHz.
% % % % 
% % % %   First line: Azimuth of the position, in hoop coordinate system.
% % % %   Second line: Elevation of the position.
% % % %   Next 256 lines: 256-point HRIR for the left ear for this position, floating point numbers, xmagnitude between -1.00 and 1.00.
% % % %   Next 256 lines: 256-point HRIR for the right ear for this position.
% % % % 
% % % %   So one position is described by 514 lines in file. These blocks are repeated for all positions necessary.

dirstr= 'c:\Rec_Setup_data\dat', bad_ch=  [8,16,83,84,97 ];

eval(['load ', dirstr, '\HRIR HRIR min_ph_flag dtf_flag freq_smoothing  inform  f00 f01 f02 n0r n1r  elc azc nsig nch npos  NN NN2 fsi df fscale  speaker_array f_low f_high   ndelay frame_length pulse_npts trapez_w_decay_r trapez_w_decay_s ']);

nsig= size(HRIR,2) ;
ntime= size(HRIR{1,1},1);
npos= size(HRIR{1,1},2);
nch= size(HRIR{1,1},3);
n_bad_ch= length(bad_ch); % channels to zero out

dt= 1/fsi; t= dt*[0:ntime-1].';
ti= 1/44100*[0:256-1].';
tmp= zeros(256,npos,nch);

%****** unwrap if need it
ii=1;
for iii=1:nch % number of channels
    for i=1:npos % HRIR{1, signal ii} (time:, position i, channel iii)
         tmp1= HRIR{1,ii}(:,i,iii);
         HRIR{1,ii}(:,i,iii)= [tmp1(nwrap:end); tmp1(1:nwrap-1)]; % add some zeros at the beginning too
    end
end
%*****
ii=1;
for iii=1:nch % number of channels
    for i=1:npos % HRIR{1, signal ii} (time:, position i, channel iii)
        tmp(:,i,iii)= interp1(t,[0;0;0;0;squeeze(HRIR{1,ii}(1:ntime-4,i,iii))], ti); % add some zeros at the beginning too
        if any(   isnan(squeeze(HRIR{1,ii}(1:ntime-4,i,iii)) ) ) ,  disp(['i= ', int2str(i), '   iii= ', int2str(iii)]), end
    end
end

%*****
% disp('zero out bad channels before normalization')

for iii=1:n_bad_ch % number of channels
    tmp(:,:,bad_ch(iii))= tmp(:,:,bad_ch(iii))*0;
end
max_hrir= max(max(max(abs(tmp)))) 
scaling_fac= 1/(1.05*max_hrir)
tmp= tmp*scaling_fac;

%%%%%% Plot data to check that it is not clipped
figure(1), clf
subplot(2,2,1), plot(squeeze(tmp(:,1,:)))
subplot(2,2,2), plot(squeeze(tmp(:,2,:))), pause
subplot(2,2,3), plot(squeeze(tmp(:,3,:))), pause
subplot(2,2,4), plot(squeeze(tmp(:,4,:))), pause

%output data
% load elc and azc for the mic array
mic_main_list_elena_c

% fid = fopen([dirstr,'\hrir_eserver.txt'],'w');
fid = fopen([dirstr,'\hrir.txt'],'w');
% HRIR{1, signal ii} (time:, position i:left or right , channel iii) 1st pos left
% right corresponds to 1 and 2
for iii=1:nch % number of channels
    if ~any(bad_ch==iii), % remove bad channels
        fprintf(fid,'%d\n%d\n',round(azc(iii)), round(elc(iii)));
        fprintf(fid,'%g\n',tmp(:,1,iii));  %   fprintf(fid,'%E\n',tmp(:,i,iii));
        fprintf(fid,'%g\n',tmp(:,2,iii));  %   fprintf(fid,'%E\n',tmp(:,i,iii));
    end
end
% load azc elc for second position:
load mic_second_list_elena_c % [ mic no., azc, elc, good_mic]
azc= mic_second_list_elena_c(:,2);
elc= mic_second_list_elena_c(:,3);
good_mic= mic_second_list_elena_c(:,4);
for ix=1:128, 
    if good_mic(ix)==0, bad_ch= [bad_ch, ix]; end % channels that are too close to 1st position ones are declared bad
end
% 2nd pos left right corresponds to 3 and 4
for iii=1:nch % number of channels
    if ~any(bad_ch==iii), % remove bad channels
        fprintf(fid,'%d\n%d\n',round(azc(iii)), round(elc(iii)));
        fprintf(fid,'%g\n',tmp(:,3,iii));  %   fprintf(fid,'%E\n',tmp(:,i,iii));
        fprintf(fid,'%g\n',tmp(:,4,iii));  %   fprintf(fid,'%E\n',tmp(:,i,iii));
    end
end

fclose(fid)
